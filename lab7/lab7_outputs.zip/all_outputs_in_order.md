# Lab 7 — outputs in order

## Cell 1 — 2B. Suggested lab schedule - Configuration and imports

```text
BUDGET=10000, BUDGET_MANY=10000, RUNS=10, SEED0=2026
```


## Cell 2 — 3. The Algorithm Catalogue (all 37) - Catalogue: (number, name, family, test problems)

| # | Algorithm | Family | Test problems |
|---|---|---|---|
| 1 | Weighted Sum | Classical | P1, P3, P4 |
| 2 | ε-Constraint | Classical | P2, P3, P5 |
| 3 | Benson's Method | Classical | P1, P7 |
| 4 | Weight Metric (p-norm, Tchebycheff) | Classical | P1, P3 |
| 5 | Value Function | Classical | P4, P14 |
| 6 | Goal Programming | Classical | P11, P7 |
| 7 | Lexicographic | Classical | P11, P7 |
| 8 | TOPSIS | Ranking/MCDM | P12, P4 |
| 9 | VIKOR | Ranking/MCDM | P12, P4 |
| 10 | VEGA | Non-elitist EA | P2, P3 |
| 11 | MOGA | Non-elitist EA | P3, P5 |
| 12 | NSGA | Non-elitist EA | P5, P7 |
| 13 | NPGA | Non-elitist EA | P3, P5 |
| 14 | NSGA-II | Elitist EA | P3, P5, P6 |
| 15 | NSGA-III | Elitist many-obj | P10_3, P10_5 |
| 16 | SPEA2 | Elitist EA | P4, P5 |
| 17 | PESA-II | Elitist EA | P3, P5 |
| 18 | MOEA/D | Decomposition | P3, P10_3 |
| 19 | MOEA/D-DE | Decomposition | P3, P5 |
| 20 | MOEA/D-ACO | Decomposition | P8 |
| 21 | Constrained NSGA-II | Constrained | P5, P6, P7 |
| 22 | MOPSO | Swarm | P4, P5 |
| 23 | MOGWO | Swarm | P5, P9 |
| 24 | MOABC | Swarm | P3, P6 |
| 25 | MOACO | Swarm | P8 |
| 26 | MOSA | Physics-inspired | P3, P5 |
| 27 | MODE | Evolutionary | P3, P5 |
| 28 | MO-TLBO | Human-inspired | P3, P5 |
| 29 | MOBA | Swarm | P3, P4 |
| 30 | MOMA | Hybrid | P5, P9 |
| 31 | RVEA | Many-objective | P10_3, P10_5 |
| 32 | IBEA | Indicator-based | P3, P14 |
| 33 | SMS-EMOA | Indicator-based | P3, P14 |
| 34 | HypE | Indicator-based | P10_3 |
| 35 | R-NSGA-II | Preference-based | P5, P14 |
| 36 | MGDA | Gradient-based | P13 |
| 37 | GradNorm | Gradient-based | P13 |



## Cell 3 — A1. Shared toolkit (moo_utils) - moo_utils: dominance, sorting, crowding, metrics


## Cell 4 — A1. Shared toolkit (moo_utils) - Unit tests for moo_utils (hand-checkable)

```text
moo_utils unit tests passed
```


## Cell 5 — A1. Shared toolkit (moo_utils) - Problem class and the 14 problems


## Cell 6 — A1. Shared toolkit (moo_utils) - Sanity checks from the PDF (verified by hand)

```text
P5 infeasible fraction of random designs: 0.03
P8 cities (seed 7):
 [[7.63, 77.99], [43.84, 72.35], [97.8, 53.85], [50.11, 7.21], [26.84, 49.99], [67.92, 80.37], [38.09, 6.59], [28.81, 90.96], [21.34, 45.21], [93.12, 2.49], [60.05, 95.01], [23.03, 54.85], [90.91, 13.32], [52.34, 75.04], [66.9, 46.78]]
P9 all-ones baseline CV error: 0.027
All problem sanity checks passed
```


## Cell 7 — A2. The 37 implementations — helpers - Common runner / logging helpers


## Cell 8 — A2.1 Weighted Sum - Shared single-objective solver for classical methods (scipy allowed here)

```text
[1] Weighted Sum: unit test passed
```

![008_A2_1_Weighted_Sum_Shared_single_objective_solver_for_classical_methods_out02.png](008_A2_1_Weighted_Sum_Shared_single_objective_solver_for_classical_methods_out02.png)


## Cell 9 — A2.2 ε-Constraint

```text
[2] ε-Constraint: unit test passed
```

![009_A2_2_Constraint_out02.png](009_A2_2_Constraint_out02.png)


## Cell 10 — A2.3 Benson's Method

```text
[3] Benson's Method: unit test passed
```

![010_A2_3_Benson_s_Method_out02.png](010_A2_3_Benson_s_Method_out02.png)


## Cell 11 — A2.4 Weight Metric (p-norm, Tchebycheff)

```text
[4] Weight Metric (p-norm, Tchebycheff): unit test passed
```

![011_A2_4_Weight_Metric_p_norm_Tchebycheff_out02.png](011_A2_4_Weight_Metric_p_norm_Tchebycheff_out02.png)


## Cell 12 — A2.5 Value Function

```text
[5] Value Function: unit test passed
  P4: preference a=(0.2,0.5,0.8) -> objectives [[0.051, -0.141], [0.03, -0.132], [0.016, -0.118]]
  P14: preference a=(0.2,0.5,0.8) -> objectives [[2.028, -18.315], [1.83, -14.606], [1.632, -10.9]]
```

![012_A2_5_Value_Function_out02.png](012_A2_5_Value_Function_out02.png)


## Cell 13 — A2.6 Goal Programming

```text
[6] Goal Programming: unit test passed
  P11 unit weights: x=[300. 200.], shortfall d-=[  0. 100.]
  P11 normalized 1/T: x=[300. 200.], shortfall d-=[  0. 100.]
  P7 unit weights: x=[48.33 41.67], shortfall d-=[1.33 0.  ]
  P7 normalized 1/T: x=[48.33 41.67], shortfall d-=[1.33 0.  ]
```

![013_A2_6_Goal_Programming_out02.png](013_A2_6_Goal_Programming_out02.png)


## Cell 14 — A2.7 Lexicographic

```text
[7] Lexicographic: unit test passed
  P11 priority f1>f2: x=[300. 200.]
  P11 priority f2>f1: x=[300. 200.]
  P7 priority f1>f2: x=[70. 20.]
  P7 priority f2>f1: x=[10. 80.]
```

![014_A2_7_Lexicographic_out02.png](014_A2_7_Lexicographic_out02.png)


## Cell 15 — A2.8 TOPSIS and A2.9 VIKOR (ranking methods, not optimizers)

```text
P12 Pareto-optimal suppliers: ['S1', 'S2', 'S3', 'S4', 'S5']
```

| Method | Ranking (best first) |
|---|---|
| TOPSIS w | S3 > S1 > S5 > S2 > S4 |
| TOPSIS w shifted | S1 > S2 > S3 > S5 > S4 |
| VIKOR v=0.25 | S1 > S2 > S5 > S3 > S4 |
| VIKOR v=0.25 shifted | S2 > S1 > S4 > S5 > S3 |
| VIKOR v=0.5 | S1 > S2 > S5 > S3 > S4 |
| VIKOR v=0.5 shifted | S2 > S1 > S3 > S5 > S4 |
| VIKOR v=0.75 | S1 > S3 > S2 > S5 > S4 |
| VIKOR v=0.75 shifted | S1 > S2 > S3 > S5 > S4 |


```text
P4 TOPSIS top-3 (risk, return): [[0.013, 0.113], [0.013, 0.114], [0.013, 0.114]]
```


## Cell 16 — A2 (shared base for algorithms 10–35)


## Cell 17 — A2.10 VEGA

```text
[10] VEGA: unit test passed
```

![017_A2_10_VEGA_out02.png](017_A2_10_VEGA_out02.png)


## Cell 18 — A2.11 MOGA

```text
[11] MOGA: unit test passed
```

![018_A2_11_MOGA_out02.png](018_A2_11_MOGA_out02.png)


## Cell 19 — A2.12 NSGA

```text
[12] NSGA: unit test passed
```

![019_A2_12_NSGA_out02.png](019_A2_12_NSGA_out02.png)


## Cell 20 — A2.13 NPGA

```text
[13] NPGA: unit test passed
```

![020_A2_13_NPGA_out02.png](020_A2_13_NPGA_out02.png)


## Cell 21 — A2.14 NSGA-II

```text
[14] NSGA-II: unit test passed
```

![021_A2_14_NSGA_II_out02.png](021_A2_14_NSGA_II_out02.png)


## Cell 22 — A2.15 NSGA-III

```text
[15] NSGA-III: unit test passed
```

![022_A2_15_NSGA_III_out02.png](022_A2_15_NSGA_III_out02.png)


## Cell 23 — A2.16 SPEA2

```text
[16] SPEA2: unit test passed
```

![023_A2_16_SPEA2_out02.png](023_A2_16_SPEA2_out02.png)


## Cell 24 — A2.17 PESA-II

```text
[17] PESA-II: unit test passed
```

![024_A2_17_PESA_II_out02.png](024_A2_17_PESA_II_out02.png)


## Cell 25 — A2.18 MOEA/D and A2.19 MOEA/D-DE

```text
[18] MOEA/D: unit test passed
```

![025_A2_18_MOEA_D_and_A2_19_MOEA_D_DE_out02.png](025_A2_18_MOEA_D_and_A2_19_MOEA_D_DE_out02.png)


## Cell 26 — A2.18 MOEA/D and A2.19 MOEA/D-DE

```text
[19] MOEA/D-DE: unit test passed
```

![026_A2_18_MOEA_D_and_A2_19_MOEA_D_DE_out02.png](026_A2_18_MOEA_D_and_A2_19_MOEA_D_DE_out02.png)


## Cell 27 — A2.20 MOEA/D-ACO

```text
[20] MOEA/D-ACO: unit test passed
```

![027_A2_20_MOEA_D_ACO_out02.png](027_A2_20_MOEA_D_ACO_out02.png)


## Cell 28 — A2.21 Constrained NSGA-II

```text
[21] Constrained NSGA-II: unit test passed
```

![028_A2_21_Constrained_NSGA_II_out02.png](028_A2_21_Constrained_NSGA_II_out02.png)


## Cell 29 — A2.22 MOPSO

```text
[22] MOPSO: unit test passed
```

![029_A2_22_MOPSO_out02.png](029_A2_22_MOPSO_out02.png)


## Cell 30 — A2.23 MOGWO

```text
[23] MOGWO: unit test passed
```

![030_A2_23_MOGWO_out02.png](030_A2_23_MOGWO_out02.png)


## Cell 31 — A2.24 MOABC

```text
[24] MOABC: unit test passed
```

![031_A2_24_MOABC_out02.png](031_A2_24_MOABC_out02.png)


## Cell 32 — A2.25 MOACO

```text
[25] MOACO: unit test passed
```

![032_A2_25_MOACO_out02.png](032_A2_25_MOACO_out02.png)


## Cell 33 — A2.26 MOSA

```text
[26] MOSA: unit test passed
```

![033_A2_26_MOSA_out02.png](033_A2_26_MOSA_out02.png)


## Cell 34 — A2.27 MODE

```text
[27] MODE: unit test passed
```

![034_A2_27_MODE_out02.png](034_A2_27_MODE_out02.png)


## Cell 35 — A2.28 MO-TLBO

```text
[28] MO-TLBO: unit test passed
```

![035_A2_28_MO_TLBO_out02.png](035_A2_28_MO_TLBO_out02.png)


## Cell 36 — A2.29 MOBA

```text
[29] MOBA: unit test passed
```

![036_A2_29_MOBA_out02.png](036_A2_29_MOBA_out02.png)


## Cell 37 — A2.30 MOMA

```text
[30] MOMA: unit test passed
```

![037_A2_30_MOMA_out02.png](037_A2_30_MOMA_out02.png)


## Cell 38 — A2.31 RVEA

```text
[31] RVEA: unit test passed
```

![038_A2_31_RVEA_out02.png](038_A2_31_RVEA_out02.png)


## Cell 39 — A2.32 IBEA

```text
[32] IBEA: unit test passed
```

![039_A2_32_IBEA_out02.png](039_A2_32_IBEA_out02.png)


## Cell 40 — A2.33 SMS-EMOA

```text
[33] SMS-EMOA: unit test passed
```

![040_A2_33_SMS_EMOA_out02.png](040_A2_33_SMS_EMOA_out02.png)


## Cell 41 — A2.34 HypE

```text
[34] HypE: unit test passed
```

![041_A2_34_HypE_out02.png](041_A2_34_HypE_out02.png)


## Cell 42 — A2.35 R-NSGA-II

```text
[35] R-NSGA-II: unit test passed
  P5: closest front point to reference is 0.018 (normalized)
  P14: closest front point to reference is 0.128 (normalized)
```

![042_A2_35_R_NSGA_II_out02.png](042_A2_35_R_NSGA_II_out02.png)


## Cell 43 — P13 — multi-task learning set-up (used by algorithms 36 and 37)


## Cell 44 — A2.36 MGDA

```text
[36] MGDA: unit test passed
toy final x — equal: [0. 0.]  MGDA: [2.5 2.5]  GradNorm: [1.224 1.224] (Pareto set: x1 = x2, -3<=x1<=3)
```

![044_A2_36_MGDA_out02.png](044_A2_36_MGDA_out02.png)

```text
final losses (cls, reg): equal [ 0.717 16.184] | MGDA [ 0.576 79.13 ] | GradNorm [ 0.665 44.984]
```


## Cell 45 — A2.37 GradNorm

```text
[37] GradNorm: unit test passed
learned GradNorm weights (cls, reg) after training: [1.703 0.297] -> the regression task (huge gradients) is down-weighted
```


## Cell 46 — A3. Implementation log

| # | Algorithm | Problem | Eval budget | HV | IGD | Spacing | Runtime | Status | n |
|---|---|---|---|---|---|---|---|---|---|
| 1 | Weighted Sum | P1 | 10000 | 1.0065 | 0.0405 | 0.0176 | 0.06s | works | 11 |
| 1 | Weighted Sum | P3 | 10000 | 0.2100 | 0.3543 | nan | 0.18s | works | 2 |
| 1 | Weighted Sum | P4 | 10000 | 0.9046 | 0.0544 | 0.1101 | 0.27s | works | 9 |
| 2 | ε-Constraint | P2 | 10000 | 1.0557 | 0.1114 | 0.1817 | 0.48s | works | 11 |
| 2 | ε-Constraint | P3 | 10000 | 0.4950 | 0.0369 | 0.0388 | 0.60s | works | 11 |
| 2 | ε-Constraint | P5 | 10000 | 1.1370 | 0.0685 | 0.0238 | 2.30s | works | 11 |
| 3 | Benson's Method | P1 | 10000 | 0.9844 | 0.0613 | 0.0686 | 0.25s | works | 12 |
| 3 | Benson's Method | P7 | 10000 | 0.6416 | 0.0422 | 0.0729 | 0.26s | works | 12 |
| 4 | Weight Metric (p-norm, Tchebycheff) | P1 | 10000 | 1.0073 | 0.0560 | 0.0599 | 0.36s | works | 11 |
| 4 | Weight Metric (p-norm, Tchebycheff) | P3 | 10000 | 0.4953 | 0.0357 | 0.0206 | 1.07s | works | 11 |
| 5 | Value Function | P14 | 10000 | 0.5382 | 0.1183 | 0.0002 | 0.22s | works | 3 |
| 5 | Value Function | P4 | 10000 | 0.8317 | 0.1896 | 0.0051 | 0.19s | works | 3 |
| 6 | Goal Programming | P11 | 10000 | 1.2100 | nan | nan | 0.01s | works | 1 |
| 6 | Goal Programming | P7 | 10000 | 0.3407 | 0.3819 | nan | 0.01s | works | 1 |
| 7 | Lexicographic | P11 | 10000 | 1.2100 | nan | nan | 0.01s | works | 1 |
| 7 | Lexicographic | P7 | 10000 | 0.2100 | 0.3524 | nan | 0.01s | works | 2 |
| 8 | TOPSIS | P12/P4 | 0 | nan | nan | nan | 0.00s | works | 5 |
| 9 | VIKOR | P12/P4 | 0 | nan | nan | nan | 0.00s | works | 5 |
| 10 | VEGA | P2 | 10000 | 1.0015 | 0.0896 | 0.0055 | 0.05s | works | 91 |
| 10 | VEGA | P3 | 10000 | 0.1090 | 0.6101 | nan | 0.09s | works | 1 |
| 11 | MOGA | P3 | 10000 | 0.5077 | 0.0237 | 0.0186 | 0.50s | works | 35 |
| 11 | MOGA | P5 | 10000 | 1.1911 | 0.0172 | 0.0242 | 0.48s | works | 53 |
| 12 | NSGA | P5 | 10000 | 1.1913 | 0.0140 | 0.0183 | 0.46s | works | 65 |
| 12 | NSGA | P7 | 10000 | 0.6267 | 0.0441 | 0.0464 | 0.39s | works | 23 |
| 13 | NPGA | P3 | 10000 | 0.4217 | 0.0635 | 0.0309 | 0.97s | works | 23 |
| 13 | NPGA | P5 | 10000 | 1.1915 | 0.0145 | 0.0499 | 1.09s | works | 46 |
| 14 | NSGA-II | P3 | 10000 | 0.5376 | 0.0045 | 0.0042 | 0.87s | works | 100 |
| 14 | NSGA-II | P5 | 10000 | 1.1950 | 0.0062 | 0.0074 | 0.87s | works | 98 |
| 14 | NSGA-II | P6 | 10000 | 1.0200 | 0.0053 | 0.0056 | 0.84s | works | 100 |
| 15 | NSGA-III | P10_3 | 10000 | 0.7330 | 0.0568 | 0.0337 | 1.61s | works | 92 |
| 15 | NSGA-III | P10_5 | 10000 | 1.1525 | 0.2196 | 0.0679 | 2.37s | works | 212 |
| 16 | SPEA2 | P4 | 10000 | 0.9701 | 0.0037 | 0.0048 | 4.02s | works | 130 |
| 16 | SPEA2 | P5 | 10000 | 1.1953 | 0.0043 | 0.0067 | 4.90s | works | 158 |
| 17 | PESA-II | P3 | 10000 | 0.5249 | 0.0108 | 0.0078 | 1.66s | works | 100 |
| 17 | PESA-II | P5 | 10000 | 1.1925 | 0.0119 | 0.0083 | 1.65s | works | 100 |
| 18 | MOEA/D | P10_3 | 10000 | 0.7098 | 0.0737 | 0.0544 | 7.10s | works | 59 |
| 18 | MOEA/D | P3 | 10000 | 0.5384 | 0.0038 | 0.0024 | 7.15s | works | 100 |
| 19 | MOEA/D-DE | P3 | 10000 | 0.5355 | 0.0044 | 0.0025 | 5.87s | works | 98 |
| 19 | MOEA/D-DE | P5 | 10000 | 1.1926 | 0.0666 | 0.0829 | 5.69s | works | 100 |
| 20 | MOEA/D-ACO | P8 | 10000 | 0.4856 | nan | 0.1589 | 7.54s | works | 3 |
| 21 | Constrained NSGA-II | P5 | 10000 | 1.1950 | 0.0062 | 0.0074 | 0.52s | works | 98 |
| 21 | Constrained NSGA-II | P6 | 10000 | 1.0201 | 0.0050 | 0.0050 | 0.51s | works | 99 |
| 21 | Constrained NSGA-II | P7 | 10000 | 0.7000 | 0.0056 | 0.0048 | 0.57s | works | 98 |
| 22 | MOPSO | P4 | 10000 | 0.9653 | 0.0071 | 0.0069 | 0.75s | works | 100 |
| 22 | MOPSO | P5 | 10000 | 1.1944 | 0.0083 | 0.0086 | 0.77s | works | 100 |
| 23 | MOGWO | P5 | 10000 | 1.1927 | 0.0121 | 0.0092 | 0.59s | works | 100 |
| 23 | MOGWO | P9 | 10000 | 1.1802 | nan | 0.0330 | 19.16s | works | 7 |
| 24 | MOABC | P3 | 10000 | 0.4509 | 0.0513 | 0.0789 | 0.29s | works | 21 |
| 24 | MOABC | P6 | 10000 | 1.0180 | 0.0069 | 0.0078 | 0.75s | works | 100 |
| 25 | MOACO | P8 | 10000 | 0.7088 | nan | 0.1196 | 5.68s | works | 8 |
| 26 | MOSA | P3 | 10000 | 0.4497 | 0.0737 | 0.0723 | 0.22s | works | 25 |
| 26 | MOSA | P5 | 10000 | 1.1947 | 0.0077 | 0.0093 | 0.67s | works | 100 |
| 27 | MODE | P3 | 10000 | 0.1100 | 0.6097 | nan | 0.14s | works | 1 |
| 27 | MODE | P5 | 10000 | 1.1814 | 0.0308 | 0.0164 | 0.17s | works | 82 |
| 28 | MO-TLBO | P3 | 10000 | 0.5304 | 0.0101 | 0.0112 | 0.29s | works | 50 |
| 28 | MO-TLBO | P5 | 10000 | 1.1932 | 0.0129 | 0.0149 | 0.30s | works | 50 |
| 29 | MOBA | P3 | 10000 | 0.1773 | 0.3863 | 0.0036 | 0.38s | works | 100 |
| 29 | MOBA | P4 | 10000 | 0.9580 | 0.0141 | 0.0068 | 1.35s | works | 100 |
| 30 | MOMA | P5 | 10000 | 1.1949 | 0.0061 | 0.0067 | 0.38s | works | 100 |
| 30 | MOMA | P9 | 10000 | 1.1896 | nan | 0.0289 | 20.31s | works | 6 |
| 31 | RVEA | P10_3 | 10000 | 0.7204 | 0.0621 | 0.0243 | 0.21s | works | 80 |
| 31 | RVEA | P10_5 | 10000 | 1.2118 | 0.2095 | 0.0493 | 0.20s | works | 200 |
| 32 | IBEA | P14 | 10000 | 0.7042 | 0.0041 | 0.0030 | 0.52s | works | 92 |
| 32 | IBEA | P3 | 10000 | 0.5369 | 0.0093 | 0.0149 | 0.51s | works | 83 |
| 33 | SMS-EMOA | P14 | 10000 | 0.7049 | 0.0036 | 0.0010 | 12.03s | works | 100 |
| 33 | SMS-EMOA | P3 | 10000 | 0.5389 | 0.0044 | 0.0049 | 12.77s | works | 100 |
| 34 | HypE | P10_3 | 10000 | 0.6982 | 0.1226 | 0.0761 | 6.82s | works | 47 |
| 35 | R-NSGA-II | P14 | 10000 | 0.6986 | 0.0066 | 0.0106 | 2.24s | works | 87 |
| 35 | R-NSGA-II | P5 | 10000 | 1.1945 | 0.0076 | 0.0104 | 2.74s | works | 85 |
| 36 | MGDA | P13 | 400 | nan | nan | nan | 0.00s | works | 0 |
| 37 | GradNorm | P13 | 400 | nan | nan | nan | 0.00s | works | 0 |


```text
algorithms logged: 37 of 37; missing: []
```


## Cell 47 — Task B — Master comparison table with evidence

**Classical**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 1 | Weighted Sum | Minimize w·f for a sweep of weights | simple, any solver; one cheap scalar solve per point; exact points on convex fronts; scales to many objectives per solve | misses non-convex regions; equal weight steps give uneven spacing; needs objective scaling; no diversity control, many solves | convex/linear problems (P1, P4, P7) | non-convex or disconnected fronts (P3) | P1: HV 1.006, IGD 0.040, Sp 0.018, 0.1s; P3: HV 0.210, IGD 0.354, 0.2s; P4: HV 0.905, IGD 0.054, Sp 0.110, 0.3s |
| 2 | ε-Constraint | Minimize one objective with the others bounded by ε, sweep ε | reaches non-convex fronts; ε grid controls spacing; handles constraints naturally; one objective per solve | needs ε ranges (ideal/nadir); infeasible ε fail; grid grows as k^(M-1); may return weakly Pareto points | non-convex bi-objective with known ranges (P3, P5) | many objectives (grid explosion) | P2: HV 1.056, IGD 0.111, Sp 0.182, 0.5s; P3: HV 0.495, IGD 0.037, Sp 0.039, 0.6s; P5: HV 1.137, IGD 0.069, Sp 0.024, 2.3s |
| 3 | Benson's Method | Maximize improvement over a feasible reference point | always dominates the start point; finds non-convex points; no weights; any feasible start works | result depends on the start point; extra variables/constraints; points cluster near x0; needs many starts for coverage | improving an existing design | when an even front is needed | P1: HV 0.984, IGD 0.061, Sp 0.069, 0.3s; P7: HV 0.642, IGD 0.042, Sp 0.073, 0.3s |
| 4 | Weight Metric (p-norm, Tchebycheff) | Minimize weighted distance to the ideal point (p=1,2,∞) | p=∞ reaches non-convex fronts; p tunes the compromise; weights give DM control; every Pareto point reachable (p=∞) | needs the ideal point; p=∞ is non-smooth (epigraph); p=1 equals weighted sum; Tchebycheff may give weak Pareto points | non-convex fronts with DM weights (P3) | when no ideal point is available | P1: HV 1.007, IGD 0.056, Sp 0.060, 0.4s; P3: HV 0.495, IGD 0.036, Sp 0.021, 1.1s |
| 5 | Value Function | Maximize the decision-maker's utility | one preferred answer; single fast solve; encodes trade-offs directly; any smooth solver | utility hard to elicit; wrong utility gives wrong answer silently; no picture of the trade-off; local solvers can be trapped | DM with a known utility (P4, P14) | exploration with unknown preferences | P4: HV 0.832, IGD 0.190, Sp 0.005, 0.2s; P14: HV 0.538, IGD 0.118, Sp 0.000, 0.2s |
| 6 | Goal Programming | Targets with deviation variables d⁻, d⁺, minimize weighted deviations | natural for target-driven DMs; an LP for linear goals; reports shortfalls explicitly; handles unattainable goals | depends on targets and weights; deviations need normalization; can return dominated solutions; no front | target planning (P11, P7) | when targets are unknown | P11: HV 1.210, 0.0s; P7: HV 0.341, IGD 0.382, 0.0s |
| 7 | Lexicographic | Optimize objectives in strict priority order | simple logic; sequence of cheap LPs; no weights; ties broken by later priorities | lower priorities ignored unless ties; very tolerance-sensitive; single solution; strict priority is rarely realistic | clear priority order (P11) | balanced trade-offs | P11: HV 1.210, 0.0s; P7: HV 0.210, IGD 0.352, 0.0s |


**Ranking/MCDM**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 8 | TOPSIS | Rank alternatives by closeness to ideal and anti-ideal | no optimizer needed; cheap; easy to explain; mixed min/max criteria | not an optimizer; rank reversal possible; compensatory: bad criterion can be masked; weight- and normalization-dependent | ranking a finite front or supplier list (P12) | generating solutions |  |
| 9 | VIKOR | Compromise ranking from S, R, Q with parameter v | explicit compromise via v; regret term protects against a very bad criterion; acceptability checks; cheap | not an optimizer; depends on weights and v; Q depends on the candidate set; compromise may be non-unique | risk-averse supplier choice (P12) | generating solutions |  |


**Non-elitist EA**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 10 | VEGA | Sub-populations each selected by one objective | simplest MOEA; no sorting needed; binary/real/perm encodings; illustrates population search | collapses to the extremes; no diversity mechanism; non-elitist; middle of the front under-represented | teaching / baseline | any serious front approximation | P2: HV 1.001, IGD 0.090, Sp 0.005, 0.1s; P3: HV 0.109, IGD 0.610, 0.1s |
| 11 | MOGA | Rank = dominators+1, fitness sharing | Pareto ranking reaches non-convex fronts; sharing preserves spread; simple fitness; any encoding | σ_share must be tuned; non-elitist; O(N²) sharing; rank ties flatten selection pressure | small bi-objective problems | many objectives, tight budgets | P3: HV 0.508, IGD 0.024, Sp 0.019, 0.5s; P5: HV 1.191, IGD 0.017, Sp 0.024, 0.5s |
| 12 | NSGA | Non-dominated fronts with sharing inside each front | explicit front layering; sharing inside fronts; non-convex fronts; historic baseline | O(MN³) sorting; σ_share tuning; non-elitist; slower than NSGA-II | baseline comparison | large populations | P5: HV 1.191, IGD 0.014, Sp 0.018, 0.5s; P7: HV 0.627, IGD 0.044, Sp 0.046, 0.4s |
| 13 | NPGA | Pareto tournament vs a comparison set, niche-count tiebreak | cheap O(N·t_dom) selection; no explicit ranking; non-convex capable; niching via counts | needs t_dom and σ; noisy tournaments; non-elitist; weak with many objectives | low-cost bi-objective runs | many objectives | P3: HV 0.422, IGD 0.064, Sp 0.031, 1.0s; P5: HV 1.192, IGD 0.015, Sp 0.050, 1.1s |


**Elitist EA**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 14 | NSGA-II | Fast non-dominated sort, crowding distance, elitism | elitist; O(MN²) sorting; parameter-free diversity; strong default for 2-3 objectives | crowding fails for 4+ objectives; most points non-dominated when M is large; ignores local geometry; favours boundaries | default for M ≤ 3 (P3, P5, P6) | M ≥ 5 | P3: HV 0.538, IGD 0.005, Sp 0.004, 0.9s; P5: HV 1.195, IGD 0.006, Sp 0.007, 0.9s; P6: HV 1.020, IGD 0.005, Sp 0.006, 0.8s |
| 16 | SPEA2 | Strength + raw fitness + k-th neighbour density, fixed archive | fine-grained fitness; truncation keeps boundaries; elitist; good spread | O(N² log N) per generation; k-th neighbour cost; archive size parameter; weaker for many objectives | bi/tri-objective with spread priority (P4, P5) | large many-objective | P4: HV 0.970, IGD 0.004, Sp 0.005, 4.0s; P5: HV 1.195, IGD 0.004, Sp 0.007, 4.9s |
| 17 | PESA-II | Grid regions of the archive, region-based selection | cheap grid density; small internal population; region selection spreads search; elitist archive | grid divisions to tune; moving grid bounds; cells grow as div^M; depends on archive size | low-dimensional objective spaces | M ≥ 5 | P3: HV 0.525, IGD 0.011, Sp 0.008, 1.7s; P5: HV 1.192, IGD 0.012, Sp 0.008, 1.7s |


**Elitist many-obj**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 15 | NSGA-III | Reference points replace crowding distance | scales to many objectives; uniform spread; elitist; adaptive normalization | population tied to reference points; empty niches on irregular fronts; more complex code; sensitive to divisions p | many-objective with regular fronts (P10) | irregular/degenerate fronts | P10_3: HV 0.733, IGD 0.057, Sp 0.034, 1.6s; P10_5: HV 1.152, IGD 0.220, Sp 0.068, 2.4s |


**Decomposition**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 18 | MOEA/D | Many Tchebycheff sub-problems with neighbour cooperation | cheap O(N·T) per generation; neighbours share information; uniform spread with good weights; scales to many objectives | weights must match front shape; T, δ, nr sensitivity; poor on disconnected fronts; needs ideal point z* | regular fronts, many objectives (P3, P10) | disconnected or degenerate fronts | P3: HV 0.538, IGD 0.004, Sp 0.002, 7.2s; P10_3: HV 0.710, IGD 0.074, Sp 0.054, 7.1s |
| 19 | MOEA/D-DE | MOEA/D with DE/rand/1 variation | DE handles complicated Pareto sets; few operators; good with variable linkage; keeps decomposition efficiency | real-valued only; F, CR to tune; diversity loss if nr large; needs bound repair | continuous problems with linkage (P5) | discrete encodings | P3: HV 0.535, IGD 0.004, Sp 0.003, 5.9s; P5: HV 1.193, IGD 0.067, Sp 0.083, 5.7s |
| 20 | MOEA/D-ACO | MOEA/D with ant-colony route construction | constructive search suits routing; neighbour pheromone sharing; native permutations; no crossover repair | N·n² pheromone memory; many ACO parameters; slow per evaluation; only constructive problems | TSP/routing (P8) | continuous problems | P8: HV 0.486, Sp 0.159, 7.5s |


**Constrained**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 21 | Constrained NSGA-II | NSGA-II with Deb's feasibility rules | no penalty parameters; cheap rules; elitist, spread preserved; works with narrow feasible sets | infeasible diversity lost; needs a CV scale; can stall on disconnected feasible regions; infeasible-only starts drift to least violation | constrained design (P5, P6) | unconstrained problems (no benefit) | P5: HV 1.195, IGD 0.006, Sp 0.007, 0.5s; P6: HV 1.020, IGD 0.005, Sp 0.005, 0.5s; P7: HV 0.700, IGD 0.006, Sp 0.005, 0.6s |


**Swarm**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 22 | MOPSO | Particles guided by personal best and archive leader | fast convergence; few parameters; archive leader selection; easy real coding | premature convergence; grid parameters; needs relaxation for discrete; needs velocity clamping | smooth continuous problems (P4) | discrete or deceptive problems | P4: HV 0.965, IGD 0.007, Sp 0.007, 0.8s; P5: HV 1.194, IGD 0.008, Sp 0.009, 0.8s |
| 23 | MOGWO | α, β, δ leaders from the archive, encircling | few parameters; archive-guided leaders; exploration→exploitation by a; simple | diversity depends on leader choice; late exploitation only; continuous only; can cluster | quick continuous problems (P5) | discrete problems | P5: HV 1.193, IGD 0.012, Sp 0.009, 0.6s; P9: HV 1.180, Sp 0.033, 19.2s |
| 24 | MOABC | Employed, onlooker, scout bees with dominance greedy choice | few parameters; scouts restore diversity; one-dimension local search; greedy dominance | slow convergence; greedy rule discards non-dominated moves; 2N evaluations/iteration; limit tuning | multimodal continuous (P3, P6) | tight budgets | P3: HV 0.451, IGD 0.051, Sp 0.079, 0.3s; P6: HV 1.018, IGD 0.007, Sp 0.008, 0.8s |
| 25 | MOACO | Two pheromone matrices, probabilistic route construction | natural for routing; two matrices encode objectives; archive deposits; no crossover repair | O(n²) memory; slow iterations; α, β, ρ tuning; pheromone stagnation | routing/graph problems (P8) | continuous problems | P8: HV 0.709, Sp 0.120, 5.7s |
| 29 | MOBA | Frequency-driven velocity, loudness and pulse-rate schedules | adaptive explore→exploit; simple updates; archive guidance; fast convergence | many parameters; leader dependence; may stagnate; needs mapping for discrete | smooth continuous (P3, P4) | discrete problems | P3: HV 0.177, IGD 0.386, Sp 0.004, 0.4s; P4: HV 0.958, IGD 0.014, Sp 0.007, 1.4s |


**Physics-inspired**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 26 | MOSA | Neighbour moves, Boltzmann acceptance, cooling | very low memory; simple; escapes local optima; any encoding | cooling schedule tuning; chains cooperate weakly; slow in many variables; needs weights for energy | memory-limited, rugged problems | tight budgets | P3: HV 0.450, IGD 0.074, Sp 0.072, 0.2s; P5: HV 1.195, IGD 0.008, Sp 0.009, 0.7s |


**Evolutionary**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 27 | MODE | DE mutation/crossover; trial replaces target only if it dominates | few parameters; strong on continuous; self-scaling steps; simple replacement | no diversity operator; F, CR to tune; continuous only; stalls if no trial dominates | continuous problems with smooth fronts | need for even spread | P3: HV 0.110, IGD 0.610, 0.1s; P5: HV 1.181, IGD 0.031, Sp 0.016, 0.2s |


**Human-inspired**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 28 | MO-TLBO | Teacher and learner phases, shrinking teaching factor | no algorithm-specific parameters; two complementary phases; elitist merge; simple | 2N evaluations/generation; teacher choice biases; continuous only; mean move can collapse diversity | parameter-light continuous runs | discrete problems | P3: HV 0.530, IGD 0.010, Sp 0.011, 0.3s; P5: HV 1.193, IGD 0.013, Sp 0.015, 0.3s |


**Hybrid**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 30 | MOMA | NSGA-II global search plus hill-climbing | local search sharpens convergence; NSGA-II diversity; any encoding with a neighbour move; fewer generations needed | extra evaluations; more parameters; premature convergence risk; neighbour step scale matters | mixed global/local landscapes (P5, P9) | very tight budgets | P5: HV 1.195, IGD 0.006, Sp 0.007, 0.4s; P9: HV 1.190, Sp 0.029, 20.3s |


**Many-objective**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 31 | RVEA | Angle-penalized distance with adaptive reference vectors | balances convergence/diversity over time; scales to many objectives; adaptive vectors; elitist | population can shrink; needs total generations; α, fr parameters; scaling issues on irregular fronts | many-objective (P10) | irregular fronts | P10_3: HV 0.720, IGD 0.062, Sp 0.024, 0.2s; P10_5: HV 1.212, IGD 0.210, Sp 0.049, 0.2s |


**Indicator-based**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 32 | IBEA | ε-indicator fitness, no diversity step | no diversity operator; any indicator plugs in; simple fitness; good for many objectives | κ sensitive; O(N²) fitness; indicator bias; needs scaled objectives | bi/many-objective with scaled objectives (P14) | unscaled objectives | P3: HV 0.537, IGD 0.009, Sp 0.015, 0.5s; P14: HV 0.704, IGD 0.004, Sp 0.003, 0.5s |
| 33 | SMS-EMOA | Steady-state, discard the least hypervolume contributor | excellent spread and convergence; steady-state; monotone hypervolume; great for 2-3 objectives | HV costly for 4+ objectives; reference-point sensitive; serial evaluations; slow wall-clock | 2-3 objectives, quality first (P3, P14) | M ≥ 5 | P3: HV 0.539, IGD 0.004, Sp 0.005, 12.8s; P14: HV 0.705, IGD 0.004, Sp 0.001, 12.0s |
| 34 | HypE | Monte-Carlo hypervolume-contribution fitness | scales HV to many objectives; time controllable via samples; no diversity operator; works for M ≥ 5 | sampling noise; S tuning; chunk removal is approximate; slow for small M | many objectives with indicator quality (P10) | tiny budgets | P10_3: HV 0.698, IGD 0.123, Sp 0.076, 6.8s |


**Preference-based**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 35 | R-NSGA-II | NSGA-II with reference-point preference and ε-clearing | focuses on the DM region; saves evaluations; ε-clearing keeps spread; reuses NSGA-II | wrong reference misguides search; ε needs tuning; no global front; DM must provide a point | DM with a target (P5, P14) | no preference information | P5: HV 1.194, IGD 0.008, Sp 0.010, 2.7s; P14: HV 0.699, IGD 0.007, Sp 0.011, 2.2s |


**Gradient-based**

| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 36 | MGDA | Min-norm combination of gradients = common descent direction | no weights; guaranteed common descent; stops at Pareto-stationary points; cheap for 2 tasks | needs gradients; local only; QP cost grows with tasks; favours small-gradient tasks | differentiable multi-task learning (P13) | non-differentiable problems |  |
| 37 | GradNorm | Adaptive task weights from gradient norms | balances gradient scales; learns weights online; cheap; works in deep nets | needs shared-layer gradient norms; α and weight-lr to tune; weights can hit the floor; heuristic, no Pareto guarantee | tasks with very different scales (P13) | non-differentiable problems |  |



## Cell 48 — Task C — Deep dive on your three assigned algorithms

```text
Deep-dive algorithms: [(7, 'Lexicographic'), (19, 'MOEA/D-DE'), (31, 'RVEA')]

[7] Lexicographic — Classical
    classical / gradient method: see its cell above

[19] MOEA/D-DE — Decomposition
    MOEA/D with DE/rand/1 variation: v = x_r1 + F (x_r2 - x_r3), binomial crossover CR=1, then polynomial mutation. F=0.5.

[31] RVEA — Many-objective
    Steps: 1) reference vectors (Das-Dennis)  2) random mating  3) translate by ideal, assign by angle  4) APD=(1+M(t/T)^a * theta/gamma)*||f||, best per vector  5) adapt vectors every fr*T gens. alpha=2, fr=0.1.
```


## Cell 49 — C2. Hand trace

```text
===== Hand trace of [7] Lexicographic =====
lexicographic orders: [300. 200.] [300. 200.]
===== Hand trace of [19] MOEA/D-DE =====
-- generation 0 (initial): x ->  objectives (normalized)
    [6.733] -> [0.8708 0.0045]
    [3.428] -> [0.0115 0.7974]
    [1.369] -> [0.1663 1.9819]
    [1.149] -> [0.2142 2.1398]
-- generation 1 (after step): x ->  objectives (normalized)
    [7.041] -> [1.0205 0.0001]
    [6.001] -> [0.5628 0.0624]
    [3.921] -> [0.053  0.5926]
    [3.921] -> [0.053  0.5926]
-- generation 2 (after step): x ->  objectives (normalized)
    [7.041] -> [1.0205 0.0001]
    [5.127] -> [0.2828 0.2192]
    [5.127] -> [0.2828 0.2192]
    [3.921] -> [0.053  0.5926]
===== Hand trace of [31] RVEA =====
-- generation 0 (initial): x ->  objectives (normalized)
    [6.733] -> [0.8708 0.0045]
    [3.428] -> [0.0115 0.7974]
    [1.369] -> [0.1663 1.9819]
    [1.149] -> [0.2142 2.1398]
-- generation 1 (after step): x ->  objectives (normalized)
    [3.428] -> [0.0115 0.7974]
    [6.733] -> [0.8708 0.0045]
-- generation 2 (after step): x ->  objectives (normalized)
    [3.629] -> [0.0247 0.7104]
    [6.733] -> [0.8708 0.0045]
```


## Cell 50 — C3. Sensitivity study

```text
[7] Lexicographic is a deterministic method: vary its input parameter and compare the outputs
  tolerance 0.0 -> x = [70. 20.]
  tolerance 0.05 -> x = [66.5 23.5]
  tolerance 0.2 -> x = [56. 34.]
```

![050_C3_Sensitivity_study_out02.png](050_C3_Sensitivity_study_out02.png)

| T (neighbours) | HV | Spacing | IGD |
|---|---|---|---|
| 5 | 0.5344 ± 0.0020 | 0.0034 | 0.0049 |
| 20 | 0.5361 ± 0.0008 | 0.0031 | 0.0044 |
| 50 | 0.5368 ± 0.0007 | 0.0032 | 0.0042 |


![050_C3_Sensitivity_study_out04.png](050_C3_Sensitivity_study_out04.png)

| alpha | HV | Spacing | IGD |
|---|---|---|---|
| 0.5 | 0.6916 ± 0.0066 | 0.0255 | 0.0735 |
| 2.0 | 0.7220 ± 0.0028 | 0.0252 | 0.0612 |
| 8.0 | 0.7406 ± 0.0008 | 0.0271 | 0.0563 |



## Cell 51 — Task D — Head-to-head comparison


## Cell 52 — D1. Continuous bi-objective: P3 (unconstrained) and P5 (constrained)

**Ranking on P3 (unconstrained), budget 10000, 10 seeds**

| Rank | # | Algorithm | HV (↑) | Spacing (↓) | IGD (↓) | Runtime |
|---|---|---|---|---|---|---|
| 1 | 16 | SPEA2 | 0.5391 ± 0.0001 | 0.0051 ± 0.0002 | 0.0033 ± 0.0001 | 2.9s |
| 2 | 33 | SMS-EMOA | 0.5388 ± 0.0000 | 0.0046 ± 0.0004 | 0.0043 ± 0.0001 | 12.3s |
| 3 | 18 | MOEA/D | 0.5384 ± 0.0001 | 0.0025 ± 0.0002 | 0.0038 ± 0.0001 | 6.8s |
| 4 | 15 | NSGA-III | 0.5382 ± 0.0001 | 0.0025 ± 0.0002 | 0.0038 ± 0.0000 | 0.7s |
| 5 | 14 | NSGA-II | 0.5372 ± 0.0003 | 0.0053 ± 0.0007 | 0.0048 ± 0.0002 | 0.5s |
| 6 | 21 | Constrained NSGA-II | 0.5372 ± 0.0003 | 0.0053 ± 0.0007 | 0.0048 ± 0.0002 | 0.5s |
| 7 | 30 | MOMA | 0.5369 ± 0.0004 | 0.0055 ± 0.0006 | 0.0050 ± 0.0003 | 0.4s |
| 8 | 32 | IBEA | 0.5372 ± 0.0002 | 0.0125 ± 0.0028 | 0.0082 ± 0.0007 | 0.5s |
| 9 | 19 | MOEA/D-DE | 0.5361 ± 0.0008 | 0.0031 ± 0.0004 | 0.0044 ± 0.0002 | 5.5s |
| 10 | 35 | R-NSGA-II | 0.5342 ± 0.0009 | 0.0108 ± 0.0004 | 0.0063 ± 0.0001 | 1.9s |
| 11 | 22 | MOPSO | 0.5329 ± 0.0017 | 0.0073 ± 0.0007 | 0.0072 ± 0.0010 | 0.9s |
| 12 | 17 | PESA-II | 0.5269 ± 0.0090 | 0.0082 ± 0.0015 | 0.0107 ± 0.0032 | 1.6s |
| 13 | 12 | NSGA | 0.5213 ± 0.0043 | 0.0164 ± 0.0053 | 0.0164 ± 0.0038 | 0.2s |
| 14 | 31 | RVEA | 0.5166 ± 0.0038 | 0.0127 ± 0.0053 | 0.0167 ± 0.0033 | 0.2s |
| 15 | 11 | MOGA | 0.5046 ± 0.0047 | 0.0243 ± 0.0084 | 0.0257 ± 0.0048 | 0.2s |
| 16 | 4 | Weight Metric (p-norm, Tchebycheff) | 0.4954 ± 0.0003 | 0.0204 ± 0.0006 | 0.0357 ± 0.0001 | 0.4s |
| 17 | 2 | ε-Constraint | 0.4950 ± 0.0000 | 0.0388 ± 0.0000 | 0.0369 ± 0.0000 | 0.2s |
| 18 | 24 | MOABC | 0.4559 ± 0.0339 | 0.0452 ± 0.0180 | 0.0488 ± 0.0152 | 0.3s |
| 19 | 26 | MOSA | 0.4469 ± 0.0249 | 0.0385 ± 0.0172 | 0.0666 ± 0.0210 | 0.2s |
| 20 | 13 | NPGA | 0.4449 ± 0.0158 | 0.0377 ± 0.0118 | 0.0548 ± 0.0087 | 0.4s |
| 21 | 23 | MOGWO | 0.4028 ± 0.1917 | 0.0080 ± 0.0010 | 0.1906 ± 0.2743 | 0.8s |
| 22 | 28 | MO-TLBO | 0.4007 ± 0.1705 | 0.0094 ± 0.0045 | 0.1589 ± 0.2111 | 0.3s |
| 23 | 1 | Weighted Sum | 0.2100 ± 0.0000 | 0.6667 ± 0.0000 | 0.3543 ± 0.0000 | 0.2s |
| 24 | 10 | VEGA | 0.1141 ± 0.0144 | 0.0636 ± 0.0377 | 0.5527 ± 0.0771 | 0.1s |
| 25 | 3 | Benson's Method | 0.1100 ± 0.0000 | nan ± nan | 0.6097 ± 0.0000 | 0.1s |
| 26 | 27 | MODE | 0.1098 ± 0.0002 | nan ± nan | 0.6098 ± 0.0001 | 0.1s |
| 27 | 29 | MOBA | 0.0668 ± 0.1287 | 0.0074 ± 0.0072 | 0.7264 ± 0.3912 | 0.3s |
| 28 | 34 | HypE | 0.0000 ± 0.0000 | 0.2133 ± 0.0841 | 2.7976 ± 0.2687 | 6.0s |


```text
P3 done in 445s
```

![052_D1_Continuous_bi_objective_P3_unconstrained_and_P5_constrained_out04.png](052_D1_Continuous_bi_objective_P3_unconstrained_and_P5_constrained_out04.png)

**Ranking on P5 (constrained), budget 10000, 10 seeds**

| Rank | # | Algorithm | HV (↑) | Spacing (↓) | IGD (↓) | Runtime |
|---|---|---|---|---|---|---|
| 1 | 33 | SMS-EMOA | 1.1956 ± 0.0000 | 0.0148 ± 0.0006 | 0.0062 ± 0.0002 | 11.6s |
| 2 | 16 | SPEA2 | 1.1954 ± 0.0001 | 0.0066 ± 0.0003 | 0.0040 ± 0.0002 | 4.4s |
| 3 | 30 | MOMA | 1.1948 ± 0.0006 | 0.0072 ± 0.0004 | 0.0067 ± 0.0015 | 0.4s |
| 4 | 14 | NSGA-II | 1.1947 ± 0.0002 | 0.0069 ± 0.0007 | 0.0069 ± 0.0006 | 0.4s |
| 5 | 21 | Constrained NSGA-II | 1.1947 ± 0.0002 | 0.0069 ± 0.0007 | 0.0069 ± 0.0006 | 0.5s |
| 6 | 35 | R-NSGA-II | 1.1948 ± 0.0002 | 0.0098 ± 0.0008 | 0.0072 ± 0.0003 | 2.6s |
| 7 | 24 | MOABC | 1.1946 ± 0.0001 | 0.0117 ± 0.0024 | 0.0073 ± 0.0004 | 0.6s |
| 8 | 26 | MOSA | 1.1947 ± 0.0001 | 0.0095 ± 0.0017 | 0.0074 ± 0.0004 | 0.7s |
| 9 | 22 | MOPSO | 1.1944 ± 0.0003 | 0.0088 ± 0.0007 | 0.0085 ± 0.0009 | 0.8s |
| 10 | 23 | MOGWO | 1.1928 ± 0.0009 | 0.0090 ± 0.0007 | 0.0113 ± 0.0020 | 0.6s |
| 11 | 17 | PESA-II | 1.1926 ± 0.0008 | 0.0089 ± 0.0007 | 0.0117 ± 0.0014 | 1.6s |
| 12 | 28 | MO-TLBO | 1.1933 ± 0.0008 | 0.0125 ± 0.0011 | 0.0125 ± 0.0015 | 0.3s |
| 13 | 29 | MOBA | 1.1935 ± 0.0005 | 0.0088 ± 0.0011 | 0.0140 ± 0.0021 | 0.8s |
| 14 | 12 | NSGA | 1.1927 ± 0.0009 | 0.0189 ± 0.0032 | 0.0153 ± 0.0026 | 0.2s |
| 15 | 19 | MOEA/D-DE | 1.1926 ± 0.0001 | 0.0818 ± 0.0031 | 0.0648 ± 0.0044 | 5.6s |
| 16 | 18 | MOEA/D | 1.1926 ± 0.0001 | 0.0829 ± 0.0006 | 0.0664 ± 0.0002 | 6.1s |
| 17 | 15 | NSGA-III | 1.1926 ± 0.0000 | 0.0831 ± 0.0003 | 0.0664 ± 0.0003 | 0.7s |
| 18 | 32 | IBEA | 1.1934 ± 0.0004 | 0.0295 ± 0.0130 | 0.1097 ± 0.0093 | 0.5s |
| 19 | 34 | HypE | 1.1917 ± 0.0009 | 0.0162 ± 0.0063 | 0.1092 ± 0.0291 | 6.2s |
| 20 | 11 | MOGA | 1.1914 ± 0.0012 | 0.0244 ± 0.0052 | 0.0173 ± 0.0027 | 0.2s |
| 21 | 31 | RVEA | 1.1906 ± 0.0010 | 0.0230 ± 0.0033 | 0.1797 ± 0.0129 | 0.2s |
| 22 | 27 | MODE | 1.1884 ± 0.0037 | 0.0405 ± 0.0228 | 0.0300 ± 0.0103 | 0.1s |
| 23 | 13 | NPGA | 1.1874 ± 0.0088 | 0.0429 ± 0.0206 | 0.0187 ± 0.0047 | 0.4s |
| 24 | 4 | Weight Metric (p-norm, Tchebycheff) | 1.1861 ± 0.0000 | 0.0735 ± 0.0000 | 0.1726 ± 0.0000 | 0.2s |
| 25 | 1 | Weighted Sum | 1.1728 ± 0.0000 | 0.3477 ± 0.0001 | 0.1370 ± 0.0000 | 0.2s |
| 26 | 3 | Benson's Method | 1.1593 ± 0.0159 | 0.0976 ± 0.0725 | 0.1171 ± 0.0241 | 0.1s |
| 27 | 10 | VEGA | 1.1504 ± 0.0084 | 0.0141 ± 0.0068 | 0.0802 ± 0.0243 | 0.0s |
| 28 | 2 | ε-Constraint | 1.1246 ± 0.0141 | 0.1174 ± 0.1141 | 0.0668 ± 0.0024 | 0.4s |


```text
P5 done in 464s
```

![052_D1_Continuous_bi_objective_P3_unconstrained_and_P5_constrained_out08.png](052_D1_Continuous_bi_objective_P3_unconstrained_and_P5_constrained_out08.png)


## Cell 53 — D2. Many-objective: P10 (M = 5) — NSGA-II, NSGA-III, MOEA/D, RVEA, HypE

**Ranking on P10 (M=5), budget 10000, 10 seeds**

| Rank | # | Algorithm | HV (↑) | Spacing (↓) | IGD (↓) | Runtime |
|---|---|---|---|---|---|---|
| 1 | 31 | RVEA | 1.2141 ± 0.0060 | 0.0504 ± 0.0025 | 0.2090 ± 0.0021 | 0.2s |
| 2 | 15 | NSGA-III | 1.1622 ± 0.0131 | 0.0725 ± 0.0054 | 0.2219 ± 0.0036 | 1.1s |
| 3 | 34 | HypE | 1.1489 ± 0.0100 | 0.1447 ± 0.0084 | 0.3449 ± 0.0104 | 7.4s |
| 4 | 18 | MOEA/D | 1.1425 ± 0.0064 | 0.1124 ± 0.0203 | 0.3411 ± 0.0088 | 7.8s |
| 5 | 14 | NSGA-II | 0.1233 ± 0.1076 | 0.1817 ± 0.0233 | 0.6099 ± 0.1149 | 0.5s |


```text
P10_3: non-dominated share of 200 random points = 0.29
P10_5: non-dominated share of 200 random points = 0.54
NSGA-II final population on M=5: mean distance of its front to the true front (IGD) = 0.610 vs NSGA-III 0.222
```

![053_D2_Many_objective_P10_M_5_NSGA_II_NSGA_III_MOEA_D_RVEA_HypE_out04.png](053_D2_Many_objective_P10_M_5_NSGA_II_NSGA_III_MOEA_D_RVEA_HypE_out04.png)


## Cell 54 — D3. Discrete: P8 — MOEA/D-ACO, MOACO, NSGA-II and MOMA (permutation operators)

**Ranking on P8 (15-city bi-objective TSP), budget 10000, 10 seeds**

| Rank | # | Algorithm | HV (↑) | Spacing (↓) | IGD (↓) | Runtime |
|---|---|---|---|---|---|---|
| 1 | 30 | MOMA | 0.7557 ± 0.0009 | 0.1131 ± 0.0119 | - | 0.8s |
| 2 | 14 | NSGA-II | 0.7542 ± 0.0038 | 0.1097 ± 0.0247 | - | 1.0s |
| 3 | 25 | MOACO | 0.7166 ± 0.0336 | 0.1070 ± 0.0092 | - | 5.6s |
| 4 | 20 | MOEA/D-ACO | 0.6379 ± 0.1362 | 0.1223 ± 0.0339 | - | 7.3s |


```text
Operators used by NSGA-II / MOMA on permutations: order crossover (OX) + segment-inversion mutation; MOMA adds inversion hill-climbing; ACO methods construct tours directly.
```

![054_D3_Discrete_P8_MOEA_D_ACO_MOACO_NSGA_II_and_MOMA_permutation_operators_out04.png](054_D3_Discrete_P8_MOEA_D_ACO_MOACO_NSGA_II_and_MOMA_permutation_operators_out04.png)

```text
shortest-distance tour: [351.8 463.7] | shortest-time tour: [411.4 366.3]
```


## Cell 55 — D4. Methods without their own front (as specified in the PDF) - 5-7: solution and the input that produced it

| Method | Input | Solution found |
|---|---|---|
| 5 Value Function | a = 0.2 | [[0.0512, -0.1413]] |
| 5 Value Function | a = 0.5 | [[0.0301, -0.1317]] |
| 5 Value Function | a = 0.8 | [[0.0158, -0.118]] |
| 6 Goal Programming | targets (2400, 600), weights [1, 1] | [300.0, 200.0] |
| 6 Goal Programming | targets (2400, 600), weights [0.0004166666666666667, 0.0016666666666666668] | [300.0, 200.0] |
| 7 Lexicographic | priority [0, 1] | [300.0, 200.0] |
| 7 Lexicographic | priority [1, 0] | [300.0, 200.0] |


| Method | Top-3 indices, w=(0.5,0.5) | Top-3 indices, w=(0.6,0.4) | Ranking |
|---|---|---|---|
| TOPSIS | [47, 48, 46] | [46, 47, 45] | flips |
| VIKOR v=0.5 | [47, 48, 46] | [46, 47, 45] | flips |


```text
Top-1 designs (mass kg, deflection m): [11.6825, 0.0006]
```

| Method | classification loss | regression loss |
|---|---|---|
| Equal weights (fixed) | 0.717 | 16.184 |
| 36 MGDA | 0.576 | 79.13 |
| 37 GradNorm | 0.665 | 44.984 |


```text
Regression gradients are ~20x larger: equal weights let that task dominate; MGDA/GradNorm rebalance by gradient scale (see A2.36-37 plots).
```


## Cell 56 — Task E — Algorithm selection reasoning

| Problem | Two suitable (evidence) | Poor choice (evidence) | Justification (convexity / M / variables / constraints / preference / budget) |
|---|---|---|---|
| P3 ZDT2 (non-convex, 2 obj, continuous) | NSGA-II (HV 0.537); MOEA/D (HV 0.538) | Weighted Sum (HV 0.210) | Pareto-based/decomposition handle the dent; Weighted Sum can only reach the end points (convexity). |
| P5 beam (constrained, continuous) | Constrained NSGA-II (HV 1.195); SPEA2 (HV 1.195) | VEGA (HV 1.150) | Deb's rules need no penalty weight and keep feasible spread; VEGA has no constraint handling or diversity. |
| P8 TSP (discrete, 2 obj) | MOEA/D-ACO (HV 0.638); MOMA (HV 0.756) | MOPSO (design argument) | ACO builds valid tours and MOMA adds local search on permutations; MOPSO is continuous and needs relaxation. |
| P10 DTLZ2 M=5 (many-objective) | NSGA-III (HV 1.162); RVEA (HV 1.214) | NSGA-II (HV 0.123) | Reference points/vectors keep pressure when most points are non-dominated; NSGA-II crowding fails. |
| P11 production planning (linear goals, priorities) | Goal Programming (HV 1.210); Lexicographic (HV 1.210) | Value Function (design argument) | LP-based goal/lexicographic solves are exact and cheap; a value function needs a utility nobody gave. |
| P14 laptop (DM reference point 1.8 kg, 12 h) | R-NSGA-II (HV 0.699); Value Function (HV 0.538) | Benson's Method (design argument) | R-NSGA-II focuses on the preferred part of the front; Benson improves a start point but ignores the preference. |



## Cell 57 — Task F — Viva preparation: executable demonstrations

```text
Q1 weighted sum (21 weights) on ZDT2: f1 of the points found -> [0. 1. 1. 1. 1.]
Q2 points in the middle of the front (0.15<f1<0.85): VEGA 0 of 1, NSGA-II 67 of 100
```

| Pair | Rule applied | Result |
|---|---|---|
| 0 vs 2 | feasible beats infeasible (F worse but CV=0) | A wins |
| 0 vs 1 | both feasible: ordinary dominance -> incomparable | tie |
| 3 vs 2 | both infeasible: smaller CV (0.5<2) wins | A wins |
| 0 vs 3 | feasible beats infeasible (3 has better F) | A wins |



## Cell 58 — Task F — Viva preparation: executable demonstrations

![058_Task_F_Viva_preparation_executable_demonstrations_out01.png](058_Task_F_Viva_preparation_executable_demonstrations_out01.png)

```text
NSGA-II HV never decreases: False | NSGA decreased 4 times (no elitism)
plateau test (last 5 checkpoints improve < 1e-4): NSGA-II False | NSGA False
```


## Cell 59 — Final check and output - Save raw results to CSV (required by Section 7)

```text
saved results/task_a_log.csv and results/task_d_runs.csv
```
