| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 35 | R-NSGA-II | NSGA-II with reference-point preference and ε-clearing | focuses on the DM region; saves evaluations; ε-clearing keeps spread; reuses NSGA-II | wrong reference misguides search; ε needs tuning; no global front; DM must provide a point | DM with a target (P5, P14) | no preference information | P5: HV 1.194, IGD 0.008, Sp 0.010, 2.7s; P14: HV 0.699, IGD 0.007, Sp 0.011, 2.2s |
