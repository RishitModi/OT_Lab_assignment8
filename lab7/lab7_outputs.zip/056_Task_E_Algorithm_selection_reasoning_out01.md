| Problem | Two suitable (evidence) | Poor choice (evidence) | Justification (convexity / M / variables / constraints / preference / budget) |
|---|---|---|---|
| P3 ZDT2 (non-convex, 2 obj, continuous) | NSGA-II (HV 0.537); MOEA/D (HV 0.538) | Weighted Sum (HV 0.210) | Pareto-based/decomposition handle the dent; Weighted Sum can only reach the end points (convexity). |
| P5 beam (constrained, continuous) | Constrained NSGA-II (HV 1.195); SPEA2 (HV 1.195) | VEGA (HV 1.150) | Deb's rules need no penalty weight and keep feasible spread; VEGA has no constraint handling or diversity. |
| P8 TSP (discrete, 2 obj) | MOEA/D-ACO (HV 0.638); MOMA (HV 0.756) | MOPSO (design argument) | ACO builds valid tours and MOMA adds local search on permutations; MOPSO is continuous and needs relaxation. |
| P10 DTLZ2 M=5 (many-objective) | NSGA-III (HV 1.162); RVEA (HV 1.214) | NSGA-II (HV 0.123) | Reference points/vectors keep pressure when most points are non-dominated; NSGA-II crowding fails. |
| P11 production planning (linear goals, priorities) | Goal Programming (HV 1.210); Lexicographic (HV 1.210) | Value Function (design argument) | LP-based goal/lexicographic solves are exact and cheap; a value function needs a utility nobody gave. |
| P14 laptop (DM reference point 1.8 kg, 12 h) | R-NSGA-II (HV 0.699); Value Function (HV 0.538) | Benson's Method (design argument) | R-NSGA-II focuses on the preferred part of the front; Benson improves a start point but ignores the preference. |
