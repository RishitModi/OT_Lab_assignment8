| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 15 | NSGA-III | Reference points replace crowding distance | scales to many objectives; uniform spread; elitist; adaptive normalization | population tied to reference points; empty niches on irregular fronts; more complex code; sensitive to divisions p | many-objective with regular fronts (P10) | irregular/degenerate fronts | P10_3: HV 0.733, IGD 0.057, Sp 0.034, 1.6s; P10_5: HV 1.152, IGD 0.220, Sp 0.068, 2.4s |
