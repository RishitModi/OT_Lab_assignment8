| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 30 | MOMA | NSGA-II global search plus hill-climbing | local search sharpens convergence; NSGA-II diversity; any encoding with a neighbour move; fewer generations needed | extra evaluations; more parameters; premature convergence risk; neighbour step scale matters | mixed global/local landscapes (P5, P9) | very tight budgets | P5: HV 1.195, IGD 0.006, Sp 0.007, 0.4s; P9: HV 1.190, Sp 0.029, 20.3s |
