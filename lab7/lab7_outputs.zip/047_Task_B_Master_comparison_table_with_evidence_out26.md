| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 31 | RVEA | Angle-penalized distance with adaptive reference vectors | balances convergence/diversity over time; scales to many objectives; adaptive vectors; elitist | population can shrink; needs total generations; α, fr parameters; scaling issues on irregular fronts | many-objective (P10) | irregular fronts | P10_3: HV 0.720, IGD 0.062, Sp 0.024, 0.2s; P10_5: HV 1.212, IGD 0.210, Sp 0.049, 0.2s |
