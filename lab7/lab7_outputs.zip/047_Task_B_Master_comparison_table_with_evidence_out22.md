| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 28 | MO-TLBO | Teacher and learner phases, shrinking teaching factor | no algorithm-specific parameters; two complementary phases; elitist merge; simple | 2N evaluations/generation; teacher choice biases; continuous only; mean move can collapse diversity | parameter-light continuous runs | discrete problems | P3: HV 0.530, IGD 0.010, Sp 0.011, 0.3s; P5: HV 1.193, IGD 0.013, Sp 0.015, 0.3s |
