| Pair | Rule applied | Result |
|---|---|---|
| 0 vs 2 | feasible beats infeasible (F worse but CV=0) | A wins |
| 0 vs 1 | both feasible: ordinary dominance -> incomparable | tie |
| 3 vs 2 | both infeasible: smaller CV (0.5<2) wins | A wins |
| 0 vs 3 | feasible beats infeasible (3 has better F) | A wins |
