| Method | Ranking (best first) |
|---|---|
| TOPSIS w | S3 > S1 > S5 > S2 > S4 |
| TOPSIS w shifted | S1 > S2 > S3 > S5 > S4 |
| VIKOR v=0.25 | S1 > S2 > S5 > S3 > S4 |
| VIKOR v=0.25 shifted | S2 > S1 > S4 > S5 > S3 |
| VIKOR v=0.5 | S1 > S2 > S5 > S3 > S4 |
| VIKOR v=0.5 shifted | S2 > S1 > S3 > S5 > S4 |
| VIKOR v=0.75 | S1 > S3 > S2 > S5 > S4 |
| VIKOR v=0.75 shifted | S1 > S2 > S3 > S5 > S4 |
