| Method | classification loss | regression loss |
|---|---|---|
| Equal weights (fixed) | 0.717 | 16.184 |
| 36 MGDA | 0.576 | 79.13 |
| 37 GradNorm | 0.665 | 44.984 |
