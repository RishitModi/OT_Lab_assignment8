| Method | Input | Solution found |
|---|---|---|
| 5 Value Function | a = 0.2 | [[0.0512, -0.1413]] |
| 5 Value Function | a = 0.5 | [[0.0301, -0.1317]] |
| 5 Value Function | a = 0.8 | [[0.0158, -0.118]] |
| 6 Goal Programming | targets (2400, 600), weights [1, 1] | [300.0, 200.0] |
| 6 Goal Programming | targets (2400, 600), weights [0.0004166666666666667, 0.0016666666666666668] | [300.0, 200.0] |
| 7 Lexicographic | priority [0, 1] | [300.0, 200.0] |
| 7 Lexicographic | priority [1, 0] | [300.0, 200.0] |
