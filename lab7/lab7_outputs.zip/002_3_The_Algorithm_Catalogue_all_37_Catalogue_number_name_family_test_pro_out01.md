| # | Algorithm | Family | Test problems |
|---|---|---|---|
| 1 | Weighted Sum | Classical | P1, P3, P4 |
| 2 | ε-Constraint | Classical | P2, P3, P5 |
| 3 | Benson's Method | Classical | P1, P7 |
| 4 | Weight Metric (p-norm, Tchebycheff) | Classical | P1, P3 |
| 5 | Value Function | Classical | P4, P14 |
| 6 | Goal Programming | Classical | P11, P7 |
| 7 | Lexicographic | Classical | P11, P7 |
| 8 | TOPSIS | Ranking/MCDM | P12, P4 |
| 9 | VIKOR | Ranking/MCDM | P12, P4 |
| 10 | VEGA | Non-elitist EA | P2, P3 |
| 11 | MOGA | Non-elitist EA | P3, P5 |
| 12 | NSGA | Non-elitist EA | P5, P7 |
| 13 | NPGA | Non-elitist EA | P3, P5 |
| 14 | NSGA-II | Elitist EA | P3, P5, P6 |
| 15 | NSGA-III | Elitist many-obj | P10_3, P10_5 |
| 16 | SPEA2 | Elitist EA | P4, P5 |
| 17 | PESA-II | Elitist EA | P3, P5 |
| 18 | MOEA/D | Decomposition | P3, P10_3 |
| 19 | MOEA/D-DE | Decomposition | P3, P5 |
| 20 | MOEA/D-ACO | Decomposition | P8 |
| 21 | Constrained NSGA-II | Constrained | P5, P6, P7 |
| 22 | MOPSO | Swarm | P4, P5 |
| 23 | MOGWO | Swarm | P5, P9 |
| 24 | MOABC | Swarm | P3, P6 |
| 25 | MOACO | Swarm | P8 |
| 26 | MOSA | Physics-inspired | P3, P5 |
| 27 | MODE | Evolutionary | P3, P5 |
| 28 | MO-TLBO | Human-inspired | P3, P5 |
| 29 | MOBA | Swarm | P3, P4 |
| 30 | MOMA | Hybrid | P5, P9 |
| 31 | RVEA | Many-objective | P10_3, P10_5 |
| 32 | IBEA | Indicator-based | P3, P14 |
| 33 | SMS-EMOA | Indicator-based | P3, P14 |
| 34 | HypE | Indicator-based | P10_3 |
| 35 | R-NSGA-II | Preference-based | P5, P14 |
| 36 | MGDA | Gradient-based | P13 |
| 37 | GradNorm | Gradient-based | P13 |
