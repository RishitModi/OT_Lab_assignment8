| Method | Top-3 indices, w=(0.5,0.5) | Top-3 indices, w=(0.6,0.4) | Ranking |
|---|---|---|---|
| TOPSIS | [47, 48, 46] | [46, 47, 45] | flips |
| VIKOR v=0.5 | [47, 48, 46] | [46, 47, 45] | flips |
