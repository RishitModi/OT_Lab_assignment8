| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 26 | MOSA | Neighbour moves, Boltzmann acceptance, cooling | very low memory; simple; escapes local optima; any encoding | cooling schedule tuning; chains cooperate weakly; slow in many variables; needs weights for energy | memory-limited, rugged problems | tight budgets | P3: HV 0.450, IGD 0.074, Sp 0.072, 0.2s; P5: HV 1.195, IGD 0.008, Sp 0.009, 0.7s |
