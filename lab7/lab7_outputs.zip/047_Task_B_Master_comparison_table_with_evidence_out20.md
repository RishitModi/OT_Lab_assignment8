| # | Algorithm | What it does | Advantages | Disadvantages | Best choice | Avoid | Evidence (own runs) |
|---|---|---|---|---|---|---|---|
| 27 | MODE | DE mutation/crossover; trial replaces target only if it dominates | few parameters; strong on continuous; self-scaling steps; simple replacement | no diversity operator; F, CR to tune; continuous only; stalls if no trial dominates | continuous problems with smooth fronts | need for even spread | P3: HV 0.110, IGD 0.610, 0.1s; P5: HV 1.181, IGD 0.031, Sp 0.016, 0.2s |
