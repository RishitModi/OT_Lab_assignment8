# Cell 37: A2.30 MOMA
class MOMA(NSGA2):
    """Steps: NSGA-II generation, then local search: pick ls_frac of the population, ls_steps neighbour moves, replace if the neighbour dominates. ls_frac=0.1, ls_steps=3."""
    ls_frac = 0.1; ls_steps = 3
    def local_search(s):
        idx = s.rng.choice(len(s.X), max(1, int(s.ls_frac * len(s.X))), replace=False)
        for _ in range(s.ls_steps):
            Xn = s.neighbor(s.X[idx]); Fn = s.evaluate(Xn); cv = s.last_cv; b = (Fn <= s.F[idx]).all(1) & (Fn < s.F[idx]).any(1)
            s.X[idx[b]], s.F[idx[b]], s.CV[idx[b]] = Xn[b], Fn[b], cv[b]
    def step(s): NSGA2.step(s); s.local_search()

def ut_30():
    m = MOMA(P3, budget=10 ** 6, seed=0, N=20, ls_frac=1.0); Fb = m.F.copy(); m.local_search(); assert (m.F <= Fb + 1e-12).all()   # hill climbing never worsens a member
A2(30, cls_runner(MOMA), unit=ut_30)
