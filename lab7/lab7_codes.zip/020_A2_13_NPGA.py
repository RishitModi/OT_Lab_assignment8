# Cell 20: A2.13 NPGA
def npga_winner(a, b, Ds, niche):
    da, db = Ds[:, a].any(), Ds[:, b].any()
    return (b if da else a) if da != db else (a if niche[a] <= niche[b] else b)

class NPGA(MOEA):
    """Steps: 1) pick 2 candidates + comparison set (10% of N)  2) dominance vs set  3) tie -> niche count  4) crossover+mutation. sigma=0.1."""
    sigma = 0.1; tdom = 0.1
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def step(s):
        D = dom_matrix(s.F); niche = np.clip(1 - cdist(s.F, s.F) / s.sigma, 0, 1).sum(1); k = max(2, int(s.tdom * s.N)); par = []
        for _ in range(s.N):
            a, b = s.rng.integers(0, s.N, 2); par.append(npga_winner(a, b, D[s.rng.integers(0, s.N, k)], niche))
        s.X = s.offspring(s.X[np.array(par)]); s.F = s.evaluate(s.X)

def ut_13():
    D = dom_matrix(np.array([[1, 1], [2, 2], [3, 3.]])); assert npga_winner(0, 2, D[[1]], np.zeros(3)) == 0   # b dominated by set member, a not
    assert npga_winner(1, 2, np.zeros((1, 3), bool), np.array([0, 5, 1.])) == 2                              # tie -> smaller niche count
A2(13, cls_runner(NPGA), unit=ut_13)
