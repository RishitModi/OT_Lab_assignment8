# Cell 36: A2.29 MOBA
class MOBA(MOEA):
    """Steps: 1) bats, loudness A=1, pulse r0  2) f=fmin+(fmax-fmin)b; v+=(x-leader)f; x+=v  3) local walk if rand>r  4) accept if rand<A and not dominated by old  5) A*=alpha, r=r0(1-exp(-gamma t))  6) archive. N=40, alpha=gamma=0.9."""
    Ndef = 40; swarm = True; fmin = 0.0; fmax = 2.0; alpha = 0.9; gamma = 0.9; r0 = 0.5; cap = 100
    def initialize(s):
        s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.V = np.zeros_like(s.X); s.A_ = np.ones(s.N); s.r_ = np.zeros(s.N)
        s.A = Archive(s.cap, 10, s.rng); s.A.add(s.X, s.F)
    def step(s):
        rg = s.p.ub - s.p.lb; L = s.A.X[s.A.pick(s.N, s.rng)]; f = s.fmin + (s.fmax - s.fmin) * s.rng.random((s.N, 1))
        s.V = np.clip(s.V + (s.X - L) * f, -.3 * rg, .3 * rg); Xn = np.clip(s.X + s.V, s.p.lb, s.p.ub); loc = s.rng.random(s.N) > s.r_
        Xn[loc] = np.clip(L[loc] + 0.02 * s.rng.normal(size=Xn[loc].shape) * rg * s.A_.mean(), s.p.lb, s.p.ub); Fn = s.evaluate(Xn)
        acc = (s.rng.random(s.N) < s.A_) & ~((s.F <= Fn).all(1) & (s.F < Fn).any(1)); s.X[acc], s.F[acc] = Xn[acc], Fn[acc]
        s.A_[acc] *= s.alpha; s.r_[acc] = s.r0 * (1 - np.exp(-s.gamma * (s.gen + 1))); s.A.add(Xn, Fn)
    def final(s): return s.dec(s.A.X)

def ut_29():
    m = MOBA(P3, budget=10 ** 6, seed=0, N=20); A0 = m.A_.copy(); m.step()
    assert (m.A_ <= A0 + 1e-12).all() and (m.A_ < A0).any() and (m.r_ <= m.r0 + 1e-12).all() and (m.r_ > 0).any()   # loudness falls, pulse rate rises (0 -> r0) after accepted moves
A2(29, cls_runner(MOBA), unit=ut_29)
