# Cell 50: C3. Sensitivity study
def mk(cls, **kw): return lambda P, s, b: cls(P, budget=b, seed=s, **kw).run().result()
SENS = {  # idx: (parameter, values, factory(value)->runner, problem)
 1: ("n_weights", [3, 6, 11], lambda v: (lambda P, s, b: finalize(P, weighted_sum(P, s, v))), "P4"),
 2: ("n_eps", [3, 6, 11], lambda v: (lambda P, s, b: finalize(P, eps_constraint(P, s, v))), "P5"),
 3: ("n_start", [3, 6, 12], lambda v: (lambda P, s, b: finalize(P, benson(P, s, v))), "P7"),
 4: ("n_weights", [3, 6, 11], lambda v: (lambda P, s, b: finalize(P, weight_metric(P, s, np.inf, v))), "P3"),
 10: ("N", [20, 50, 100], lambda v: mk(VEGA, N=v), "P3"), 11: ("sigma", [0.02, 0.1, 0.5], lambda v: mk(MOGA, sigma=v), "P3"),
 12: ("sigma", [0.02, 0.1, 0.5], lambda v: mk(NSGA, sigma=v), "P5"), 13: ("sigma", [0.02, 0.1, 0.5], lambda v: mk(NPGA, sigma=v), "P3"),
 14: ("N", [20, 50, 100], lambda v: mk(NSGA2, N=v), "P3"), 15: ("divisions", [19, 49, 99], lambda v: mk(NSGA3, div=v), "P3"),
 16: ("N", [20, 50, 100], lambda v: mk(SPEA2, N=v), "P4"), 17: ("grid div", [5, 10, 20], lambda v: mk(PESA2, div=v), "P3"),
 18: ("T (neighbours)", [5, 20, 50], lambda v: mk(MOEAD, T=v), "P3"), 19: ("T (neighbours)", [5, 20, 50], lambda v: mk(MOEADDE, T=v), "P3"),
 20: ("rho", [0.02, 0.1, 0.5], lambda v: mk(MOEAD_ACO, rho=v), "P8"), 21: ("N", [20, 50, 100], lambda v: mk(CNSGA2, N=v), "P5"),
 22: ("inertia w", [0.1, 0.4, 0.9], lambda v: mk(MOPSO, w=v), "P5"), 23: ("N", [20, 50, 100], lambda v: mk(MOGWO, N=v), "P5"),
 24: ("limit", [3, 10, 30], lambda v: mk(MOABC, limit=v), "P3"), 25: ("rho", [0.02, 0.1, 0.5], lambda v: mk(MOACO, rho=v), "P8"),
 26: ("T0", [0.05, 0.5, 5.0], lambda v: mk(MOSA, T0=v), "P3"), 27: ("F", [0.2, 0.5, 0.9], lambda v: mk(MODE, Fm=v), "P3"),
 28: ("N", [20, 50, 100], lambda v: mk(MOTLBO, N=v), "P3"), 29: ("alpha", [0.5, 0.9, 0.99], lambda v: mk(MOBA, alpha=v), "P3"),
 30: ("ls_frac", [0.0, 0.1, 0.5], lambda v: mk(MOMA, ls_frac=v), "P5"), 31: ("alpha", [0.5, 2.0, 8.0], lambda v: mk(RVEA, alpha=v), "P10_3"),
 32: ("kappa", [0.01, 0.05, 0.5], lambda v: mk(IBEA, kappa=v), "P3"), 33: ("N", [20, 50, 100], lambda v: mk(SMSEMOA, N=v), "P3"),
 34: ("samples S", [200, 1000, 3000], lambda v: mk(HypE, S=v), "P10_3"), 35: ("eps", [0.001, 0.02, 0.2], lambda v: mk(RNSGA2, eps=v), "P5")}

def sensitivity(idx):
    """Run 3 parameter values x RUNS seeds; plot mean±std HV and one front per value."""
    if idx in (5, 6, 7, 8, 9, 36, 37):                    # deterministic or non-front methods: vary the input and report the answers
        print(f"[{idx}] {NAME[idx]} is a deterministic method: vary its input parameter and compare the outputs")
        if idx == 5: [print("  a =", a, "->", P4.f(value_function(P4, 0, (a,)))[0].round(4).tolist()) for a in (0.2, 0.5, 0.8)]
        elif idx == 6: [print("  weights", w, "-> x =", goal_programming(P11.lin, [2400, 600], w)[0].round(2)) for w in ([1, 1], [1, 5], [5, 1])]
        elif idx == 7: [print("  tolerance", t, "-> x =", lexicographic(P7.lin, [0, 1], t).round(2)) for t in (0.0, 0.05, 0.2)]
        elif idx in (8, 9): [print("  weight shift", d, "->", rank((topsis if idx == 8 else vikor)(Mx, np.array([.3 + d, .3 - d, .2, .2]), bf), idx == 8)) for d in (0, .1, .2)]
        else:
            for lr in (0.0005, 0.002, 0.005): h, _ = train_mtl("mgda" if idx == 36 else "gradnorm", 0, 300, lr); print(f"  lr={lr}: final (cls, reg) losses", h[-1].round(3))
        return
    par, vals, fac, pn = SENS[idx]; P = PROBS[pn]; b = BUDGET_MANY if P.m > 2 else BUDGET; res = {}; fig, ax = plt.subplots(1, 2, figsize=(10, 3.4))
    for v in vals:
        H, S_, G = [], [], []
        for r in range(RUNS):
            Fn = fac(v)(P, SEED0 + r, b); h, sp, ig = metrics(P, Fn); H.append(h); S_.append(sp); G.append(ig)
            if r == 0 and P.m == 2: R = P.denorm(Fn); ax[1].scatter(R[:, 0], R[:, 1], s=10, label=f"{par}={v}")
        res[v] = (np.mean(H), np.std(H), np.nanmean(S_), np.nanmean(G))
    ax[0].errorbar(range(len(vals)), [res[v][0] for v in vals], [res[v][1] for v in vals], fmt="o-", capsize=4); ax[0].set_xticks(range(len(vals))); ax[0].set_xticklabels(vals)
    ax[0].set_xlabel(par); ax[0].set_ylabel("HV (mean ± std)"); ax[0].set_title(f"[{idx}] {NAME[idx]} on {pn}")
    if P.pf is not None and P.m == 2: ax[1].plot(P.pf[:, 0], P.pf[:, 1], "k.", ms=2)
    ax[1].legend(fontsize=7); plt.tight_layout(); plt.show()
    table([(v, f"{res[v][0]:.4f} ± {res[v][1]:.4f}", f"{res[v][2]:.4f}", "-" if np.isnan(res[v][3]) else f"{res[v][3]:.4f}") for v in vals], [par, "HV", "Spacing", "IGD"])
for i in DEEP: sensitivity(i)
