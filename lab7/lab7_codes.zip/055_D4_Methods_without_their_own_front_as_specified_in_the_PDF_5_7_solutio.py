# Cell 55: D4. Methods without their own front (as specified in the PDF) - 5-7: solution and the input that produced it
# --- 5-7: solution and the input that produced it ---
table([("5 Value Function", f"a = {a}", P4.f(value_function(P4, 0, (a,)))[0].round(4).tolist()) for a in (0.2, 0.5, 0.8)] +
      [("6 Goal Programming", f"targets (2400, 600), weights {w}", goal_programming(P11.lin, [2400, 600], w)[0].round(1).tolist()) for w in ([1, 1], [1 / 2400, 1 / 600])] +
      [("7 Lexicographic", f"priority {o}", lexicographic(P11.lin, o).round(1).tolist()) for o in ([0, 1], [1, 0])], ["Method", "Input", "Solution found"])
# --- 8-9: top-3 on the NSGA-II front of P5, then shift one weight by 0.1 ---
Fr5 = P5.denorm(RES[("P5", 14)]["front"]); Fr5 = Fr5[np.argsort(Fr5[:, 0])]; bn = np.array([False, False]); w_a, w_b = np.array([.5, .5]), np.array([.6, .4])
def top3(sc, hi): o = np.argsort(-sc if hi else sc)[:3]; return o.tolist()
rows = []
for nm, f_, hi in (("TOPSIS", lambda w: topsis(Fr5, w, bn), True), ("VIKOR v=0.5", lambda w: vikor(Fr5, w, bn, 0.5), False)):
    a, b_ = top3(f_(w_a), hi), top3(f_(w_b), hi); rows.append((nm, a, b_, "flips" if a != b_ else "stable"))
table(rows, ["Method", "Top-3 indices, w=(0.5,0.5)", "Top-3 indices, w=(0.6,0.4)", "Ranking"]); print("Top-1 designs (mass kg, deflection m):", Fr5[rows and top3(topsis(Fr5, w_a, bn), True)[0]].round(4).tolist())
# --- 36-37: both task losses against fixed equal weights ---
table([("Equal weights (fixed)", *hE[-1].round(3)), ("36 MGDA", *hM[-1].round(3)), ("37 GradNorm", *hG[-1].round(3))], ["Method", "classification loss", "regression loss"])
print("Regression gradients are ~20x larger: equal weights let that task dominate; MGDA/GradNorm rebalance by gradient scale (see A2.36-37 plots).")
