# Cell 33: A2.26 MOSA
class MOSA(MOEA):
    """Steps: 1) chains with weight vectors, T0  2) neighbour move  3) accept if dominates / dE<=0 / rand<exp(-dE/T)  4) archive  5) T*=alpha (geometric). N=30 chains, T0=0.5, Tend=1e-3."""
    Ndef = 30; T0 = 0.5; Tend = 1e-3; cap = 100
    def initialize(s):
        M = s.p.m; t = np.linspace(0, 1, s.N); s.w = np.c_[t, 1 - t] if M == 2 else s.rng.dirichlet(np.ones(M), s.N)
        s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.T = s.T0; s.cool = (s.Tend / s.T0) ** (1 / max(1, s.budget // s.N))
        s.A = Archive(s.cap, 10, s.rng); s.A.add(s.X, s.F)
    def step(s):
        Xn = s.neighbor(s.X); Fn = s.evaluate(Xn); dE = (s.w * (Fn - s.F)).sum(1); dom = (Fn <= s.F).all(1) & (Fn < s.F).any(1)
        acc = dom | (dE <= 0) | (s.rng.random(s.N) < np.exp(-np.maximum(dE, 0) / s.T)); s.X[acc], s.F[acc] = Xn[acc], Fn[acc]
        s.A.add(Xn, Fn); s.T *= s.cool
    def final(s): return s.dec(s.A.X)

def ut_26():
    assert np.exp(-0.1 / 0.01) < np.exp(-0.1 / 1.0)                                       # worse moves are accepted less often at low temperature
    m = MOSA(P3, budget=3000, seed=0, N=30).run(); assert m.T < m.T0 * 0.5
A2(26, cls_runner(MOSA), unit=ut_26)
