# Cell 11: A2.4 Weight Metric (p-norm, Tchebycheff)
def weight_metric(p, seed=0, pnorm=2, n_w=11):
    """Steps: 1) weights w  2) min (sum w|f-z|^p)^(1/p), or min t s.t. w f <= t for p=inf  3) sweep w."""
    rng = np.random.default_rng(seed); out = []; n = p.n
    for w in np.linspace(0.02, 0.98, n_w):
        wv = np.r_[w, 1 - w]
        if np.isinf(pnorm):
            x = _solve(p, lambda y: y[-1], rng, cons=[{"type": "ineq", "fun": lambda y, wv=wv: y[n] - wv * _fn(p, y[:n])}], aug=1)
        else:
            x = _solve(p, lambda x, wv=wv: np.sum(wv * np.abs(_fn(p, x)) ** pnorm) ** (1 / pnorm), rng)
        if x is not None: out.append(x)
    return np.array(out)

def ut_4():
    x = weight_metric(P1, 0, np.inf, 3)[1]                    # w = 0.5: equal weights -> balanced point x = 5
    assert abs(x[0] - 5) < 0.05
    Fn = finalize(P3, weight_metric(P3, 0, np.inf, 9)); assert ((Fn[:, 0] > 0.05) & (Fn[:, 0] < 0.95)).any()   # Tchebycheff reaches non-convex middle
A2(4, lambda P, s, b: finalize(P, weight_metric(P, s, np.inf)), unit=ut_4)
