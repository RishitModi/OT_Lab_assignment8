# Cell 35: A2.28 MO-TLBO
class MOTLBO(MOEA):
    """Steps: 1) class of learners  2) teacher = random non-dominated learner; Xn=X+r(T-TF*mean), TF=2-t/T  3) learner phase with random partner  4) merge, non-dominated sort + crowding. N=50."""
    Ndef = 50; swarm = True
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def merge(s, Xn):
        Xn = np.clip(Xn, s.p.lb, s.p.ub); Fn = s.evaluate(Xn); XU, FU = np.vstack([s.X, Xn]), np.vstack([s.F, Fn]); sel, _, _ = env_select(FU, None, s.N); s.X, s.F = XU[sel], FU[sel]
    def step(s):
        T = s.X[s.rng.choice(nds(s.F)[0])]; TF = 2 - s.evals / s.budget; s.merge(s.X + s.rng.random(s.X.shape) * (T - TF * s.X.mean(0)))
        j = s.rng.integers(0, s.N, s.N); d = (s.F <= s.F[j]).all(1) & (s.F < s.F[j]).any(1); sg = np.where(d, 1.0, -1.0)[:, None]
        s.merge(s.X + s.rng.random(s.X.shape) * sg * (s.X - s.X[j]))

def ut_28():
    m = MOTLBO(P3, budget=10 ** 6, seed=0, N=30); h0 = hv(m.F[nds(m.F)[0]], P3.ref); m.step()
    assert len(m.X) == 30 and hv(m.F[nds(m.F)[0]], P3.ref) >= h0 - 1e-12                  # elitist merge never loses hypervolume
    assert 1 <= 2 - 0.5 <= 2                                                              # teaching factor stays in [1,2] and shrinks
A2(28, cls_runner(MOTLBO), unit=ut_28)
