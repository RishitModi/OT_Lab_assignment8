# Cell 45: A2.37 GradNorm
def ut_37():
    w = gradnorm_update(np.ones(2), np.array([1., 1.]), np.array([1., 1.]), np.array([10., 1.]))
    assert w[0] < 1 < w[1] and abs(w.sum() - 2) < 1e-9                                      # large-gradient task is down-weighted, weights keep sum = number of tasks
ut_37(); print("[37] GradNorm: unit test passed")
print("learned GradNorm weights (cls, reg) after training:", wG.round(3), "-> the regression task (huge gradients) is down-weighted" if wG[1] < wG[0] else "")
LOG.append(dict(idx=37, name="GradNorm", prob="P13", budget=400, hv=np.nan, sp=np.nan, igd=np.nan, rt=0, status="works", n=0))
