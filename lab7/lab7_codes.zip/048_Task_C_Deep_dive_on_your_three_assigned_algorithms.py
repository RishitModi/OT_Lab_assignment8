# Cell 48: Task C — Deep dive on your three assigned algorithms
ROLL = 44                                             # <-- set your roll number (00-99); R=7 gives algorithms 7, 19, 31
DEEP = [((ROLL - 1) % 37) + 1, ((ROLL + 11) % 37) + 1, ((ROLL + 23) % 37) + 1]
assert [((7 - 1) % 37) + 1, ((7 + 11) % 37) + 1, ((7 + 23) % 37) + 1] == [7, 19, 31]       # example from the PDF
assert [((0 - 1) % 37) + 1, ((0 + 11) % 37) + 1, ((0 + 23) % 37) + 1] == [37, 12, 24]      # R=00 example
assert [((99 - 1) % 37) + 1, ((99 + 11) % 37) + 1, ((99 + 23) % 37) + 1] == [25, 37, 12]   # R=99 example
print("Deep-dive algorithms:", [(i, NAME[i]) for i in DEEP])

CLS = {10: VEGA, 11: MOGA, 12: NSGA, 13: NPGA, 14: NSGA2, 15: NSGA3, 16: SPEA2, 17: PESA2, 18: MOEAD, 19: MOEADDE, 20: MOEAD_ACO, 21: CNSGA2,
       22: MOPSO, 23: MOGWO, 24: MOABC, 25: MOACO, 26: MOSA, 27: MODE, 28: MOTLBO, 29: MOBA, 30: MOMA, 31: RVEA, 32: IBEA, 33: SMSEMOA, 34: HypE, 35: RNSGA2}
for i in DEEP:                                        # docstrings = steps + default parameters (reuse in the study card)
    print(f"\n[{i}] {NAME[i]} — {FAMILY[i]}"); print("   ", (CLS[i].__doc__ if i in CLS else "classical / gradient method: see its cell above").strip())
