# Cell 18: A2.11 MOGA
def moga_fitness(F, sigma):
    N = len(F); rank = 1 + dom_matrix(F).sum(0); o = np.argsort(rank, kind="stable"); pos = np.empty(N); pos[o] = N - np.arange(N); fit = np.empty(N)
    for r in np.unique(rank): m = rank == r; fit[m] = pos[m].mean()
    return fit / np.clip(1 - cdist(F, F) / sigma, 0, 1).sum(1), rank

class MOGA(MOEA):
    """Steps: 1) rank=1+#dominators  2) rank-based fitness averaged per rank  3) sharing  4) roulette selection  5) crossover+mutation. sigma=0.1."""
    sigma = 0.1
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def step(s):
        sf, _ = moga_fitness(s.F, s.sigma); par = s.rng.choice(s.N, s.N, p=sf / sf.sum())
        s.X = s.offspring(s.X[par]); s.F = s.evaluate(s.X)

def ut_11():
    F = np.array([[1, 5], [2, 3], [4, 1], [4, 4.], [5, 5.]]); sf, r = moga_fitness(F, 0.5)
    assert (r[:3] == 1).all() and r[3] > 1 and r[4] > r[3]          # rank = 1 + dominators
    F2 = np.array([[1, 3], [1, 3.0001], [3, 1.]]); sf2, _ = moga_fitness(F2, 1.0); assert sf2[2] > sf2[0]   # crowded twins get lower shared fitness
A2(11, cls_runner(MOGA), unit=ut_11)
