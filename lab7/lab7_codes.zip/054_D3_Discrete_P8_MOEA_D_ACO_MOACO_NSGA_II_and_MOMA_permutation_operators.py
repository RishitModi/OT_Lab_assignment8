# Cell 54: D3. Discrete: P8 — MOEA/D-ACO, MOACO, NSGA-II and MOMA (permutation operators)
D3_IDS = [20, 25, 14, 30]
for i in D3_IDS: run_many(i, cls_runner(CLS[i]), "P8")
rtab("P8", D3_IDS, f"Ranking on P8 (15-city bi-objective TSP), budget {BUDGET}, {RUNS} seeds")
print("Operators used by NSGA-II / MOMA on permutations: order crossover (OX) + segment-inversion mutation; MOMA adds inversion hill-climbing; ACO methods construct tours directly.")
fig, ax = plt.subplots(figsize=(5, 3.6))
for i in D3_IDS: R = P8.denorm(RES[("P8", i)]["front"]); ax.scatter(R[:, 0], R[:, 1], s=14, label=NAME[i])
ax.scatter(*np.array([[_e1[0], _e1[1]], [_e2[0], _e2[1]]]).T, c="k", marker="*", s=90, label="best-D / best-T (2-opt)"); ax.set_xlabel("distance"); ax.set_ylabel("time"); ax.legend(fontsize=7); plt.show()
print("shortest-distance tour:", _e1.round(1), "| shortest-time tour:", _e2.round(1))
