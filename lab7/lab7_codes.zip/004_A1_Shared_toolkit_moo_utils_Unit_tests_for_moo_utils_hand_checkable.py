# Cell 4: A1. Shared toolkit (moo_utils) - Unit tests for moo_utils (hand-checkable)
# ---- Unit tests for moo_utils (hand-checkable) ----
# Car example: (price k$, 0-100 time s) — cheap/slow vs expensive/fast; both minimized
cars = np.array([[20, 12], [30, 8], [25, 10], [35, 9], [28, 11], [40, 6]], float)
fr = nds(cars); assert set(fr[0]) == {0, 1, 2, 5} and set(fr[1]) == {3, 4}       # (35,9) and (28,11) are dominated
assert dominates(np.array([1, 1]), np.array([2, 2])) and not dominates(np.array([1, 3]), np.array([2, 2]))
c = crowding(np.array([[0, 4], [1, 2], [2, 1], [4, 0]], float)); assert np.isinf(c[0]) and np.isinf(c[3]) and abs(c[1] - (2/4 + 3/4)) < 1e-9
assert abs(hv2d(np.array([[1, 3], [2, 2], [3, 1]], float), np.array([4, 4.])) - 6.0) < 1e-9  # staircase area = 6
assert abs(hv_mc(np.array([[0.5, 0.5, 0.5]]), np.ones(3), 40000) - 0.125) < 0.01
# Deb's three rules: feasible beats infeasible; both feasible -> dominance; both infeasible -> smaller CV
Ft = np.array([[5., 5.], [1., 1.], [2., 2.], [9., 9.]]); CVt = np.array([0, 3, 1, 0.])
D = dom_matrix(Ft, CVt)
assert D[0, 1] and not D[1, 0]        # rule 1: feasible > infeasible (even if infeasible has better F)
assert D[0, 3] and not D[3, 0]        # rule 2: both feasible -> usual dominance
assert D[2, 1] and not D[1, 2]        # rule 3: both infeasible -> smaller violation wins
assert abs(igd(np.array([[0, 0], [1, 1.]]), np.array([[0, 0.]])) - np.sqrt(2) / 2) < 1e-9
print("moo_utils unit tests passed")
