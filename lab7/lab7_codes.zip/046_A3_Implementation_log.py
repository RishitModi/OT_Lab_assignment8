# Cell 46: A3. Implementation log
def show_log():
    rows = [(r["idx"], r["name"], r["prob"], r["budget"], f"{r['hv']:.4f}", f"{r['igd']:.4f}", f"{r['sp']:.4f}", f"{r['rt']:.2f}s", r["status"], r["n"])
            for r in sorted(LOG, key=lambda r: (r["idx"], r["prob"]))]
    table(rows, ["#", "Algorithm", "Problem", "Eval budget", "HV", "IGD", "Spacing", "Runtime", "Status", "n"])
show_log()
done = sorted({r["idx"] for r in LOG}); print("algorithms logged:", len(done), "of 37; missing:", sorted(set(range(1, 38)) - set(done)))
