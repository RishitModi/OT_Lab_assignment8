# Cell 5: A1. Shared toolkit (moo_utils) - Problem class and the 14 problems
# ---- Problem class and the 14 problems ----
class Problem:
    """name, n vars, bounds, m objectives, kind in {real,int,bin,perm}; f(X)->(F raw minimized, CV>=0)."""
    def __init__(s, name, n, lb, ub, m, fun, kind="real", g=None, pf=None, ideal=None, nadir=None, pref=None, lin=None):
        s.name, s.n, s.m, s.fun, s.kind, s.g, s.lin, s.pref = name, n, m, fun, kind, g, lin, pref
        s.lb = np.full(n, lb, float) if np.isscalar(lb) else np.array(lb, float)
        s.ub = np.full(n, ub, float) if np.isscalar(ub) else np.array(ub, float)
        s.pf = None if pf is None else thin(pf, 500)
        s.ideal = np.array(ideal if ideal is not None else pf.min(0), float)
        s.nadir = np.array(nadir if nadir is not None else pf.max(0), float)
        s.ref = np.full(m, 1.1); s.pf_n = None if s.pf is None else s.norm(s.pf)
    def f(s, X): return s.fun(np.atleast_2d(X))
    def norm(s, F): return (F - s.ideal) / (s.nadir - s.ideal)
    def denorm(s, Fn): return Fn * (s.nadir - s.ideal) + s.ideal
    def init(s, rng, N):
        if s.kind == "bin": return (rng.random((N, s.n)) < 0.5).astype(float)
        if s.kind == "perm": return np.array([rng.permutation(s.n) for _ in range(N)])
        return s.repair(s.lb + rng.random((N, s.n)) * (s.ub - s.lb))
    def repair(s, X):
        if s.kind == "perm": return X
        if s.kind == "bin":
            X = (X > 0.5).astype(float); z = X.sum(1) == 0; X[z, 0] = 1; return X
        X = np.clip(X, s.lb, s.ub); return np.round(X) if s.kind == "int" else X

Z = lambda X: np.zeros(len(X))
# P1 — factory speed
P1 = Problem("P1", 1, 1, 10, 2, lambda X: (np.c_[(X[:, 0] - 3) ** 2, (X[:, 0] - 7) ** 2], Z(X)),
             pf=(lambda x: np.c_[(x - 3) ** 2, (x - 7) ** 2])(np.linspace(3, 7, 500)[:, None])[:, :, 0] if False else
                np.c_[(np.linspace(3, 7, 500) - 3) ** 2, (np.linspace(3, 7, 500) - 7) ** 2])
# P2 — fleet sizing (real and integer)
_p2 = lambda X: (np.c_[100 / X[:, 0], X[:, 0] ** 2], Z(X))
_p2i = lambda X: _p2(np.round(X))
P2 = Problem("P2", 1, 1, 10, 2, _p2, pf=np.c_[100 / np.linspace(1, 10, 500), np.linspace(1, 10, 500) ** 2])
P2i = Problem("P2i", 1, 1, 10, 2, _p2i, kind="int", pf=np.c_[100 / np.arange(1, 11), np.arange(1, 11) ** 2.], ideal=[10, 1], nadir=[100, 100])
# P3 — ZDT2 (n=10)
def _zdt2(X):
    f1 = X[:, 0]; g = 1 + 9 * X[:, 1:].mean(1); return np.c_[f1, g * (1 - (f1 / g) ** 2)], Z(X)
_t = np.linspace(0, 1, 500); P3 = Problem("P3", 10, 0, 1, 2, _zdt2, pf=np.c_[_t, 1 - _t ** 2])
# P4 — portfolio (repair by normalization)
MU = np.array([.08, .12, .15, .10])
SIG = np.array([[.010, .002, .001, .003], [.002, .040, .006, .004], [.001, .006, .090, .005], [.003, .004, .005, .020]])
def _p4(X):
    s = X.sum(1, keepdims=True); W = np.where(s > 1e-9, X / np.maximum(s, 1e-9), 0.25)
    return np.c_[np.einsum("ij,jk,ik->i", W, SIG, W), -(W @ MU)], Z(X)
_r = np.random.default_rng(0)
_W = np.vstack([_r.dirichlet(np.full(4, a), 100000) for a in (0.2, 1, 4)] + [np.eye(4)])
_pf4 = nd2d(_p4(_W)[0]); P4 = Problem("P4", 4, 0, 1, 2, _p4, pf=_pf4)
# P5 — cantilever beam (stress limit as constraint)
def _p5(X):
    b, h = X[:, 0], X[:, 1]; F = np.c_[7850 * b * h, 4 * 1000 / (200e9 * b * h ** 3)]
    return F, np.maximum(0, (2.4e-5 - b * h ** 2) / 2.4e-5)
_B, _H = np.meshgrid(np.linspace(.01, .1, 500), np.linspace(.02, .2, 500)); _XY = np.c_[_B.ravel(), _H.ravel()]
_F5, _C5 = _p5(_XY); _pf5 = nd2d(_F5[_C5 <= 0])
P5 = Problem("P5", 2, [.01, .02], [.1, .2], 2, _p5, g=lambda x: np.array([(x[0] * x[1] ** 2 - 2.4e-5) * 1e5]), pf=_pf5,
             pref=np.array([20.0, 5e-4]))
# P6 — Binh-Korn
def _p6(X):
    x1, x2 = X[:, 0], X[:, 1]; F = np.c_[4 * x1 ** 2 + 4 * x2 ** 2, (x1 - 5) ** 2 + (x2 - 5) ** 2]
    return F, np.maximum(0, (x1 - 5) ** 2 + x2 ** 2 - 25) + np.maximum(0, 7.7 - (x1 - 8) ** 2 - (x2 + 3) ** 2)
_A, _Bb = np.meshgrid(np.linspace(0, 5, 700), np.linspace(0, 3, 420)); _XY = np.c_[_A.ravel(), _Bb.ravel()]
_F6, _C6 = _p6(_XY); _pf6 = nd2d(_F6[_C6 <= 0])
P6 = Problem("P6", 2, [0, 0], [5, 3], 2, _p6, pf=_pf6,
             g=lambda x: np.array([25 - (x[0] - 5) ** 2 - x[1] ** 2, (x[0] - 8) ** 2 + (x[1] + 3) ** 2 - 7.7]))
# P7 — water allocation (maximize -> minimize negatives)
_p7 = lambda X: (np.c_[-0.8 * X[:, 0], -1.2 * X[:, 1]], np.maximum(0, X.sum(1) - 90) / 90)
_x1 = np.linspace(10, 70, 300); _pf7 = np.c_[-0.8 * _x1, -1.2 * (90 - _x1)]
P7 = Problem("P7", 2, [10, 20], [90, 90], 2, _p7, pf=_pf7, g=lambda x: np.array([90 - x[0] - x[1]]),
             pref=np.array([-40., -50.]), lin=dict(C=np.array([[.8, 0], [0, 1.2]]), A=np.array([[1., 1.]]), b=np.array([90.]), lb=[10, 20], ub=[90, 90]))
# P8 — bi-objective TSP (15 cities, numpy seed 7)
np.random.seed(7)
CITY = np.random.uniform(0, 100, (15, 2)); _U = np.triu(np.random.uniform(0.5, 2.0, (15, 15)), 1); _U = _U + _U.T
DIST = cdist(CITY, CITY); TIME = DIST * _U
def _p8(X):
    X = X.astype(int); nxt = np.roll(X, -1, 1); return np.c_[DIST[X, nxt].sum(1), TIME[X, nxt].sum(1)], Z(X)
def nn_tour(C, s0=0):
    t = [s0]; left = set(range(len(C))) - {s0}
    while left: j = min(left, key=lambda k: C[t[-1], k]); t.append(j); left.remove(j)
    return np.array(t)
def two_opt(C, t):
    t = t.copy(); n = len(t); imp = True
    while imp:
        imp = False
        for i in range(1, n - 1):
            for j in range(i + 1, n):
                a, b, c, d = t[i - 1], t[i], t[j], t[(j + 1) % n]
                if C[a, c] + C[b, d] < C[a, b] + C[c, d] - 1e-12: t[i:j + 1] = t[i:j + 1][::-1].copy(); imp = True
    return t
_rg = np.random.default_rng(1)
def best_tour(C): return min((two_opt(C, _rg.permutation(15)) for _ in range(30)), key=lambda t: C[t, np.roll(t, -1)].sum())
T_D, T_T = best_tour(DIST), best_tour(TIME); _e1, _e2 = _p8(T_D[None])[0][0], _p8(T_T[None])[0][0]
P8 = Problem("P8", 15, 0, 14, 2, _p8, kind="perm", ideal=[_e1[0], _e2[1]], nadir=[_e2[0], _e1[1]])
P8.D, P8.Tm = DIST, TIME
# P9 — feature selection (binary): 5-NN + 5-fold CV coded by hand; data loaded with scikit-learn
from sklearn.datasets import load_breast_cancer
_d = load_breast_cancer(); _rs = np.random.default_rng(3); _ix = _rs.permutation(len(_d.target))[:300]
_Xd = (_d.data[_ix] - _d.data[_ix].mean(0)) / _d.data[_ix].std(0); _yd = _d.target[_ix]
_T9 = ((_Xd[:, None, :] - _Xd[None, :, :]) ** 2).astype(np.float32)          # per-feature squared differences
_fold = np.arange(300) % 5; _same = _fold[:, None] == _fold[None, :]
def knn_cv_error(mask):
    """5-fold CV error of 5-NN restricted to the selected features."""
    Dm = _T9 @ mask.astype(np.float32); Dm[_same] = np.inf                  # neighbours only from other folds
    nb = np.argpartition(Dm, 5, axis=1)[:, :5]; pred = (_yd[nb].sum(1) >= 3).astype(int)
    return 1 - (pred == _yd).mean()
def _p9(X):
    X = (X > 0.5).astype(float); k = X.sum(1); F = np.zeros((len(X), 2)); cv = (k == 0).astype(float)
    for i in range(len(X)): F[i] = (1.0, 0) if k[i] == 0 else (knn_cv_error(X[i]), k[i])
    return F, cv
P9 = Problem("P9", 30, 0, 1, 2, _p9, kind="bin", ideal=[0, 1], nadir=[0.4, 30])
BASE_ERR = knn_cv_error(np.ones(30))
# P10 — DTLZ2
def make_dtlz2(M):
    def fun(X):
        g = ((X[:, M - 1:] - .5) ** 2).sum(1); c, s_ = np.cos(X * np.pi / 2), np.sin(X * np.pi / 2); F = np.empty((len(X), M))
        for m in range(M): F[:, m] = (1 + g) * np.prod(c[:, :M - 1 - m], axis=1) * (s_[:, M - 1 - m] if m > 0 else 1)
        return F, np.zeros(len(X))
    z = np.abs(np.random.default_rng(5).normal(size=(2500, M))); z /= np.linalg.norm(z, axis=1, keepdims=True)
    return Problem(f"P10_{M}", M + 9, 0, 1, M, fun, pf=z, ideal=np.zeros(M), nadir=np.ones(M))
P10_3, P10_5 = make_dtlz2(3), make_dtlz2(5)
# P11 — production planning (max profit, units)
_p11 = lambda X: (np.c_[-(4 * X[:, 0] + 6 * X[:, 1]), -(X[:, 0] + X[:, 1])],
                  np.maximum(0, 2 * X[:, 0] + 3 * X[:, 1] - 1200) / 1200 + np.maximum(0, 4 * X[:, 0] + 2 * X[:, 1] - 1600) / 1600)
P11 = Problem("P11", 2, 0, 600, 2, _p11, ideal=[-2400, -500], nadir=[0, 0], pf=np.array([[-2400., -500.]]) if False else None,
              g=lambda x: np.array([1200 - 2 * x[0] - 3 * x[1], 1600 - 4 * x[0] - 2 * x[1]]),
              lin=dict(C=np.array([[4., 6.], [1., 1.]]), A=np.array([[2., 3.], [4., 2.]]), b=np.array([1200., 1600.]), lb=[0, 0], ub=[600, 600]))
# P12 — supplier selection data (cost min, quality max, delivery min, reliability max)
P12 = dict(names=["S1", "S2", "S3", "S4", "S5"], w=np.array([.3, .3, .2, .2]), benefit=np.array([False, True, False, True]),
           M=np.array([[120, 8, 10, 92], [100, 7, 14, 88], [140, 9, 7, 95], [90, 6, 18, 80], [130, 8, 9, 90]], float))
# P14 — laptop design with a preference
_p14 = lambda X: (np.c_[.4 + .05 * X[:, 0] + .012 * X[:, 1], -(.2 * X[:, 1] / (.5 + .03 * X[:, 0]))], Z(X))
_x2 = np.linspace(40, 90, 300); P14 = Problem("P14", 2, [13, 40], [17, 90], 2, _p14, pf=_p14(np.c_[np.full(300, 13.), _x2])[0],
                                              pref=np.array([1.8, -12.]))
PROBS = {"P1": P1, "P2": P2, "P2i": P2i, "P3": P3, "P4": P4, "P5": P5, "P6": P6, "P7": P7, "P8": P8, "P9": P9,
         "P10_3": P10_3, "P10_5": P10_5, "P11": P11, "P14": P14}
