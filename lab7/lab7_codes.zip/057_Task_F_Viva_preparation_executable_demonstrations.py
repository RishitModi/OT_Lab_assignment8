# Cell 57: Task F — Viva preparation: executable demonstrations
# Q1: weighted sum on ZDT2 keeps only the end points; Q2: VEGA vs NSGA-II spread on P3
Fw = finalize(P3, weighted_sum(P3, 0, 21)); print("Q1 weighted sum (21 weights) on ZDT2: f1 of the points found ->", np.sort(Fw[:, 0]).round(2))
Fv, Fn2 = RES[("P3", 10)]["front"], RES[("P3", 14)]["front"]; mid = lambda F: int(((F[:, 0] > .15) & (F[:, 0] < .85)).sum())
print(f"Q2 points in the middle of the front (0.15<f1<0.85): VEGA {mid(Fv)} of {len(Fv)}, NSGA-II {mid(Fn2)} of {len(Fn2)}")
# Q6: Deb's three rules on the four candidates (F, CV)
cand = np.array([[2., 2.], [1., 3.], [3., 1.], [1., 1.]]); cv = np.array([0., 0., 2., 0.5]); D = dom_matrix(cand, cv)
table([(f"{a} vs {b}", rule, "A wins" if D[a, b] else ("B wins" if D[b, a] else "tie")) for a, b, rule in
       [(0, 2, "feasible beats infeasible (F worse but CV=0)"), (0, 1, "both feasible: ordinary dominance -> incomparable"), (3, 2, "both infeasible: smaller CV (0.5<2) wins"), (0, 3, "feasible beats infeasible (3 has better F)")]],
      ["Pair", "Rule applied", "Result"])
