# Cell 59: Final check and output - Save raw results to CSV (required by Section 7)
# ---- Save raw results to CSV (required by Section 7) ----
import csv
os.makedirs("results", exist_ok=True)
with open("results/task_a_log.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["idx", "algorithm", "problem", "budget", "HV", "IGD", "Spacing", "runtime_s", "status"])
    for r in LOG: w.writerow([r["idx"], r["name"], r["prob"], r["budget"], r["hv"], r["igd"], r["sp"], round(r["rt"], 3), r["status"]])
with open("results/task_d_runs.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["problem", "idx", "algorithm", "seed", "HV", "IGD", "Spacing"])
    for (pn, i), r in RES.items():
        for k in range(len(r["hv"])): w.writerow([pn, i, NAME[i], SEED0 + k, r["hv"][k], r["igd"][k], r["sp"][k]])
print("saved results/task_a_log.csv and results/task_d_runs.csv")
