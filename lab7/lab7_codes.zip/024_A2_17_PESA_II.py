# Cell 24: A2.17 PESA-II
class PESA2(MOEA):
    """Steps: 1) small internal population  2) archive of non-dominated points with grid  3) region tournament + random member  4) variation  5) insert into archive, truncate crowded cell. div=10, cap=100."""
    Ndef = 20; cap = 100; div = 10
    def initialize(s):
        s.A = Archive(s.cap, s.div, s.rng); s.X = s.newpop(s.N); F = s.evaluate(s.X); s.A.add(s.X, F)
    def step(s):
        par = s.A.X[s.A.region_pick(s.N, s.rng)]; s.X = s.offspring(par); s.A.add(s.X, s.evaluate(s.X))
    def final(s): return s.dec(s.A.X)

def ut_17():
    A = Archive(cap=2, div=4, rng=np.random.default_rng(0)); F = np.array([[0.0, 1.0], [0.01, 0.99], [1.0, 0.0]]); A.add(F, F)
    assert len(A.F) == 2 and (A.F[:, 0] == 1.0).any() and (A.F[:, 0] == 1.0).sum() == 1   # the lone point survives; the crowded cell is thinned
    assert A.counts(np.array([[0, 0], [0.01, 0.01], [1, 1.]])).tolist() == [2, 2, 1]
A2(17, cls_runner(PESA2), unit=ut_17)
