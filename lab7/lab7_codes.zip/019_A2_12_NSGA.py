# Cell 19: A2.12 NSGA
def nsga_fitness(F, sigma):
    fit = np.zeros(len(F)); cur = float(len(F))
    for f in nds(F):
        sf = cur / np.clip(1 - cdist(F[f], F[f]) / sigma, 0, 1).sum(1); fit[f] = sf; cur = sf.min() * 0.9
    return fit

class NSGA(MOEA):
    """Steps: 1) sort into fronts  2) dummy fitness per front  3) sharing within front  4) roulette  5) crossover+mutation. sigma=0.1."""
    sigma = 0.1
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def step(s):
        fit = nsga_fitness(s.F, s.sigma); par = s.rng.choice(s.N, s.N, p=fit / fit.sum()); s.X = s.offspring(s.X[par]); s.F = s.evaluate(s.X)

def ut_12():
    F = np.array([[1, 4], [2, 3], [3, 2], [4, 1], [3, 4.], [4, 3.]]); fr = nds(F); fit = nsga_fitness(F, 0.3)
    assert fit[fr[0]].min() > fit[fr[1]].max()                                            # every front-1 point beats every front-2 point
A2(12, cls_runner(NSGA), unit=ut_12)
