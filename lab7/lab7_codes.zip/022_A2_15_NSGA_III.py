# Cell 22: A2.15 NSGA-III
def associate(Zn, W):
    """Perpendicular distance of each point to each reference line -> (nearest line, distance)."""
    Wn = W / np.linalg.norm(W, axis=1, keepdims=True); proj = Zn @ Wn.T
    d = np.sqrt(np.maximum((Zn ** 2).sum(1)[:, None] - proj ** 2, 0)); return d.argmin(1), d.min(1)

class NSGA3(MOEA):
    """Steps: 1) random mating, offspring  2) sort union  3) normalize (ideal, extreme points, intercepts)  4) associate to reference lines  5) niche-preserving fill of last front. Divisions p={2:99,3:12,5:6}."""
    div = None
    def initialize(s):
        M = s.p.m; s.W = das_dennis(M, s.div or {2: 99, 3: 12, 5: 6}.get(M, 4)); s.N = int(np.ceil(len(s.W) / 4) * 4)
        s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def niching(s, FU, St, Fl, K):
        S = np.r_[St, Fl].astype(int); Z = FU[S] - FU[S].min(0); M = Z.shape[1]; E = []
        for j in range(M): w = np.full(M, 1e-6); w[j] = 1; E.append(Z[np.argmin((Z / w).max(1))])
        try:
            a = 1 / np.linalg.solve(np.array(E), np.ones(M)); ok = np.all(a > 1e-6) and np.all(np.isfinite(a))
        except np.linalg.LinAlgError: ok = False
        if not ok: a = Z.max(0)
        ref, d = associate(Z / np.maximum(a, 1e-9), s.W); nS = len(St); rho = np.bincount(ref[:nS], minlength=len(s.W)).astype(float)
        mr, md = ref[nS:], d[nS:]; left = np.ones(len(Fl), bool); chosen = []
        while len(chosen) < K:
            cnt = np.bincount(mr[left], minlength=len(s.W)); rr = np.where(cnt > 0, rho, np.inf); j = s.rng.choice(np.where(rr == rr.min())[0])
            mem = np.where(left & (mr == j))[0]; pick = mem[np.argmin(md[mem])] if rho[j] == 0 else s.rng.choice(mem)
            chosen.append(Fl[pick]); left[pick] = False; rho[j] += 1
        return np.array(chosen, int)
    def step(s):
        off = s.offspring(s.X[s.rng.permutation(s.N)]); Fo = s.evaluate(off); XU, FU = np.vstack([s.X, off]), np.vstack([s.F, Fo]); fr = nds(FU); sel = []; k = 0
        while k < len(fr) and len(sel) + len(fr[k]) <= s.N: sel += list(fr[k]); k += 1
        if len(sel) < s.N: sel += list(s.niching(FU, np.array(sel, int), fr[k], s.N - len(sel)))
        s.X, s.F = XU[sel], FU[sel]

def ut_15():
    W = das_dennis(3, 4); assert len(W) == 15 and np.allclose(W.sum(1), 1)                # C(6,2)=15 reference points on the simplex
    ref, d = associate(0.5 * W[1:] + 1e-9, W[1:]); assert (ref == np.arange(14)).all() and d.max() < 1e-6   # a point on a ray is associated with that ray
A2(15, cls_runner(NSGA3), unit=ut_15)
