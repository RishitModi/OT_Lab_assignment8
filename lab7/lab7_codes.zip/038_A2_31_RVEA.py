# Cell 38: A2.31 RVEA
class RVEA(MOEA):
    """Steps: 1) reference vectors (Das-Dennis)  2) random mating  3) translate by ideal, assign by angle  4) APD=(1+M(t/T)^a * theta/gamma)*||f||, best per vector  5) adapt vectors every fr*T gens. alpha=2, fr=0.1."""
    alpha = 2.0; fr = 0.1; div = None
    def initialize(s):
        M = s.p.m; W = das_dennis(M, s.div or {2: 99, 3: 12, 5: 6}.get(M, 4)); s.W0 = W / np.linalg.norm(W, axis=1, keepdims=True); s.Wv = s.W0.copy(); s.N = len(W)
        s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.Tg = max(1, s.budget // s.N)
    def apd_select(s, F):
        Z = F - F.min(0); nr = np.linalg.norm(Z, axis=1) + 1e-12; ang = np.arccos(np.clip((Z @ s.Wv.T) / nr[:, None], -1, 1)); asg = ang.argmin(1)
        cw = s.Wv @ s.Wv.T; np.fill_diagonal(cw, -1); gam = np.arccos(np.clip(cw.max(1), -1, 1)) + 1e-12; sel = []
        for v in np.unique(asg):
            m = np.where(asg == v)[0]; sel.append(m[np.argmin((1 + F.shape[1] * (s.gen / s.Tg) ** s.alpha * ang[m, v] / gam[v]) * nr[m])])
        return np.array(sel)
    def step(s):
        off = s.offspring(s.X[s.rng.integers(0, len(s.X), s.N)]); XU, FU = np.vstack([s.X, off]), np.vstack([s.F, s.evaluate(off)]); sel = s.apd_select(FU); s.X, s.F = XU[sel], FU[sel]
        if s.gen > 0 and s.gen % max(1, int(s.fr * s.Tg)) == 0:
            v = s.W0 * (s.F.max(0) - s.F.min(0) + 1e-12); s.Wv = v / np.linalg.norm(v, axis=1, keepdims=True)

def ut_31():
    m = RVEA(P10_3, budget=10 ** 6, seed=0); sel = m.apd_select(np.array([[1., 0, 0], [2., 0, 0], [0, 1., 0]]))
    assert set(sel) == {0, 2}                                                             # same vector -> smaller distance wins; other vector keeps its own member
A2(31, cls_runner(RVEA), unit=ut_31)
