# Cell 21: A2.14 NSGA-II
class NSGA2(MOEA):
    """Steps: 1) tournament on (rank, crowding)  2) crossover+mutation  3) merge parents+offspring  4) fast non-dominated sort  5) fill by fronts, crowding on last. Pc=0.9, eta_c=15, eta_m=20."""
    use_cv = False
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.CV = s.last_cv
    def survive(s, F, CV, n): return env_select(F, CV, n)
    def step(s):
        cv = s.CV if s.use_cv else None; _, rank, crowd = s.survive(s.F, cv, len(s.F))
        par = s.tourn(len(s.X), s.N, lambda i, j: (rank[i] < rank[j]) | ((rank[i] == rank[j]) & (crowd[i] > crowd[j])))
        off = s.offspring(s.X[par]); Fo = s.evaluate(off); XU, FU, CVU = np.vstack([s.X, off]), np.vstack([s.F, Fo]), np.r_[s.CV, s.last_cv]
        sel, _, _ = s.survive(FU, CVU if s.use_cv else None, s.N); s.X, s.F, s.CV = XU[sel], FU[sel], CVU[sel]

def ut_14():
    F = np.array([[0, 4], [1, 2.5], [2, 2], [2.1, 1.9], [4, 0], [5, 5.]]); sel, rank, crowd = env_select(F, None, 3)
    assert 0 in sel and 4 in sel and 5 not in sel                                       # boundary points (inf crowding) survive, dominated point dropped
A2(14, cls_runner(NSGA2), unit=ut_14)
