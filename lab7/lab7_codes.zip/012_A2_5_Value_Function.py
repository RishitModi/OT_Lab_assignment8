# Cell 12: A2.5 Value Function
def value_function(p, seed=0, alphas=(0.2, 0.5, 0.8)):
    """Steps: 1) elicit utility U(f)  2) maximize U over feasible x  3) one solution per preference a."""
    rng = np.random.default_rng(seed); out = []
    for a in alphas:
        U = lambda x, a=a: -(max(1.05 - _fn(p, x)[0], 1e-9) ** a) * (max(1.05 - _fn(p, x)[1], 1e-9) ** (1 - a))
        x = _solve(p, U, rng)
        if x is not None: out.append(x)
    return np.array(out)

def ut_5():
    F = P1.f(value_function(P1, 0, (0.2, 0.5, 0.8)))[0]
    assert F[0, 0] > F[1, 0] > F[2, 0] - 1e-9 and abs(F[1, 0] - 4) < 0.3    # larger a weights f1 more -> smaller f1; a=.5 -> x=5
def run_5(P, s, b):
    X = value_function(P, s); print(f"  {P.name}: preference a=(0.2,0.5,0.8) -> objectives", P.f(X)[0].round(3).tolist()); return finalize(P, X)
A2(5, run_5, unit=ut_5)
