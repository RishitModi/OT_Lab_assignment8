# Cell 56: Task E — Algorithm selection reasoning
def ev(i, pn):
    if (pn, i) in RES: return f"HV {np.mean(RES[(pn, i)]['hv']):.3f}"
    r = [x for x in LOG if x["idx"] == i and x["prob"] == pn and not np.isnan(x["hv"])]
    return f"HV {r[0]['hv']:.3f}" if r else "design argument"
E = [("P3 ZDT2 (non-convex, 2 obj, continuous)", (14, 18), 1, "Pareto-based/decomposition handle the dent; Weighted Sum can only reach the end points (convexity)."),
     ("P5 beam (constrained, continuous)", (21, 16), 10, "Deb's rules need no penalty weight and keep feasible spread; VEGA has no constraint handling or diversity."),
     ("P8 TSP (discrete, 2 obj)", (20, 30), 22, "ACO builds valid tours and MOMA adds local search on permutations; MOPSO is continuous and needs relaxation."),
     ("P10 DTLZ2 M=5 (many-objective)", (15, 31), 14, "Reference points/vectors keep pressure when most points are non-dominated; NSGA-II crowding fails."),
     ("P11 production planning (linear goals, priorities)", (6, 7), 5, "LP-based goal/lexicographic solves are exact and cheap; a value function needs a utility nobody gave."),
     ("P14 laptop (DM reference point 1.8 kg, 12 h)", (35, 5), 3, "R-NSGA-II focuses on the preferred part of the front; Benson improves a start point but ignores the preference.")]
table([(p, f"{NAME[a]} ({ev(a, pn)}); {NAME[b]} ({ev(b, pn)})", f"{NAME[c]} ({ev(c, pn)})", why)
       for (p, (a, b), c, why), pn in zip(E, ["P3", "P5", "P8", "P10_5", "P11", "P14"])], ["Problem", "Two suitable (evidence)", "Poor choice (evidence)", "Justification (convexity / M / variables / constraints / preference / budget)"])
