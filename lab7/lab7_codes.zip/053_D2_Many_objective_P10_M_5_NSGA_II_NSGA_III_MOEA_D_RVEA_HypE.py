# Cell 53: D2. Many-objective: P10 (M = 5) — NSGA-II, NSGA-III, MOEA/D, RVEA, HypE
D2_IDS = [14, 15, 18, 31, 34]
for i in D2_IDS: run_many(i, cls_runner(CLS[i]), "P10_5")
rtab("P10_5", D2_IDS, f"Ranking on P10 (M=5), budget {BUDGET_MANY}, {RUNS} seeds")
# why NSGA-II degrades: share of non-dominated individuals in a random population and in the NSGA-II population
rr = np.random.default_rng(0)
for Pm in (P10_3, P10_5): Fr = Pm.f(Pm.init(rr, 200))[0]; print(f"{Pm.name}: non-dominated share of 200 random points = {len(nds(Fr)[0]) / 200:.2f}")
Fn5 = RES[("P10_5", 14)]["front"]; print("NSGA-II final population on M=5: mean distance of its front to the true front (IGD) =", f"{np.nanmean(RES[('P10_5', 14)]['igd']):.3f}",
                                        "vs NSGA-III", f"{np.nanmean(RES[('P10_5', 15)]['igd']):.3f}")
# parallel-coordinate view of the M=5 fronts
fig, axs = plt.subplots(1, 5, figsize=(16, 2.8), sharey=True)
for ax, i in zip(axs, D2_IDS):
    F = RES[("P10_5", i)]["front"]
    for f in F[:60]: ax.plot(range(5), f, c="C0", alpha=.3)
    ax.set_title(NAME[i], fontsize=9)
plt.tight_layout(); plt.show()
