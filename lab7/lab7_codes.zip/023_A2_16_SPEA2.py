# Cell 23: A2.16 SPEA2
def spea2_fit(F):
    D = dom_matrix(F); S = D.sum(1); R = (D * S[:, None]).sum(0); k = max(1, int(np.sqrt(len(F))))
    return R + 1 / (np.sort(cdist(F, F), 1)[:, min(k, len(F) - 1)] + 2)

def spea2_select(F, n):
    fit = spea2_fit(F); nd = np.where(fit < 1)[0]
    if len(nd) < n: return np.argsort(fit)[:n]
    if len(nd) == n: return nd
    idx = list(range(len(nd))); Dm = cdist(F[nd], F[nd]); np.fill_diagonal(Dm, np.inf)
    while len(idx) > n: sub = np.sort(Dm[np.ix_(idx, idx)], 1); idx.pop(np.lexsort(sub.T[::-1])[0])
    return nd[idx]

class SPEA2(MOEA):
    """Steps: 1) union population+archive  2) fitness R+D  3) environmental selection (non-dominated, truncate/fill) -> archive  4) tournament on archive  5) variation. Archive=N."""
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.AX = np.empty((0, s.p.n)); s.AF = np.empty((0, s.p.m))
    def step(s):
        XU, FU = np.vstack([s.X, s.AX]) if len(s.AX) else s.X, np.vstack([s.F, s.AF]) if len(s.AF) else s.F
        sel = spea2_select(FU, s.N); s.AX, s.AF = XU[sel], FU[sel]; fit = spea2_fit(s.AF)
        par = s.tourn(len(s.AX), s.N, lambda i, j: fit[i] < fit[j]); s.X = s.offspring(s.AX[par]); s.F = s.evaluate(s.X)
    def final(s): return s.dec(np.vstack([s.AX, s.X]))

def ut_16():
    F = np.array([[1, 4], [2, 2], [4, 1], [3, 3.], [5, 5.]]); fit = spea2_fit(F)
    assert (fit[:3] < 1).all() and (fit[3:] >= 1).all()                                  # non-dominated <1, dominated >=1
    assert len(spea2_select(np.random.default_rng(0).random((30, 2)), 10)) == 10
A2(16, cls_runner(SPEA2), unit=ut_16)
