# Cell 16: A2 (shared base for algorithms 10–35)
def sbx(rng, A, B, lb, ub, eta=15, pc=0.9):
    """Simulated binary crossover -> two children."""
    u = rng.random(A.shape); be = np.where(u <= .5, (2 * u) ** (1 / (eta + 1)), (1 / (2 * (1 - u + 1e-12))) ** (1 / (eta + 1)))
    c1 = .5 * ((1 + be) * A + (1 - be) * B); c2 = .5 * ((1 - be) * A + (1 + be) * B)
    sw = rng.random(A.shape) < .5; c1, c2 = np.where(sw, c2, c1), np.where(sw, c1, c2); m = rng.random((len(A), 1)) < pc
    return np.where(m, c1, A), np.where(m, c2, B)

def polymut(rng, X, lb, ub, eta=20, pm=None):
    """Polynomial mutation (per-gene probability 1/n)."""
    pm = 1 / X.shape[1] if pm is None else pm; u = rng.random(X.shape); mu = rng.random(X.shape) < pm
    d = np.where(u < .5, (2 * u) ** (1 / (eta + 1)) - 1, 1 - (2 * (1 - u)) ** (1 / (eta + 1)))
    return np.clip(X + mu * d * (ub - lb), lb, ub)

def ox(rng, a, b):
    """Order crossover for permutations."""
    n = len(a); i, j = sorted(rng.choice(n, 2, replace=False)); c = -np.ones(n, int); c[i:j + 1] = a[i:j + 1]
    seg = set(a[i:j + 1].tolist()); order = [g for g in np.r_[b[j + 1:], b[:j + 1]] if g not in seg]
    for k, g in zip(list(range(j + 1, n)) + list(range(0, i)), order): c[k] = g
    return c

def invert(rng, x):
    i, j = sorted(rng.choice(len(x), 2, replace=False)); y = x.copy(); y[i:j + 1] = y[i:j + 1][::-1]; return y

def das_dennis(M, p):
    """Uniform reference points on the unit simplex (C(p+M-1, M-1) points)."""
    def rec(M, p):
        if M == 1: return [[p]]
        return [[i] + r for i in range(p + 1) for r in rec(M - 1, p - i)]
    return np.array(rec(M, p), float) / p

def tcheb(F, lam, z): return np.max(np.maximum(lam, 1e-6) * np.abs(F - z), axis=-1)

class MOEA:
    """Base: initialize() -> evaluate() -> step() -> run(); result() = feasible non-dominated set (normalized objectives)."""
    Ndef = 100; swarm = False
    def __init__(s, prob, budget=5000, seed=0, N=None, **kw):
        s.p, s.budget, s.rng, s.N, s.evals, s.gen = prob, budget, np.random.default_rng(seed), N or s.Ndef, 0, 0
        for k, v in kw.items(): setattr(s, k, v)
        s.relax = s.swarm and prob.kind == "bin"          # swarm methods work in [0,1]^n and threshold at 0.5 for binary problems
        s.initialize()
    def evaluate(s, X):
        s.evals += len(X); F, CV = s.p.f((X > .5).astype(float) if s.relax else X); s.last_cv = CV
        return s.p.norm(F) + PEN * CV[:, None]
    def dec(s, X): return (X > .5).astype(float) if s.relax else X
    def newpop(s, n): return s.rng.random((n, s.p.n)) if s.relax else s.p.init(s.rng, n)
    def repair(s, X): return np.clip(X, 0, 1) if s.relax else s.p.repair(X)
    def cross(s, A, B):
        k = s.p.kind
        if s.relax or k in ("real", "int"): C1, C2 = sbx(s.rng, A, B, s.p.lb, s.p.ub)
        elif k == "bin": m = s.rng.random(A.shape) < .5; C1, C2 = np.where(m, A, B), np.where(m, B, A)
        else: C1 = np.array([ox(s.rng, a, b) for a, b in zip(A, B)]); C2 = np.array([ox(s.rng, b, a) for a, b in zip(A, B)])
        return s.repair(C1), s.repair(C2)
    def mutate(s, X):
        k = s.p.kind
        if s.relax or k in ("real", "int"): Y = polymut(s.rng, X, s.p.lb, s.p.ub)
        elif k == "bin": Y = np.where(s.rng.random(X.shape) < 1 / X.shape[1], 1 - X, X)
        else: Y = np.array([invert(s.rng, x) if s.rng.random() < .3 else x for x in X])
        return s.repair(Y)
    def offspring(s, P):
        """Pair consecutive parents, crossover, mutate -> same number of children."""
        n = len(P); P = np.vstack([P, P[:1]]) if n % 2 else P; C1, C2 = s.cross(P[0::2], P[1::2]); return s.mutate(np.vstack([C1, C2]))[:n]
    def neighbor(s, X):
        """Small random move (used by local search / annealing)."""
        k = s.p.kind
        if s.relax or k in ("real", "int"): return s.repair(X + s.rng.normal(0, .05, X.shape) * (s.p.ub - s.p.lb))
        if k == "bin":
            Y = X.copy(); j = s.rng.integers(0, X.shape[1], len(X)); Y[np.arange(len(X)), j] = 1 - Y[np.arange(len(X)), j]; return s.repair(Y)
        return np.array([invert(s.rng, x) for x in X])
    def tourn(s, pop_n, n, better):
        i, j = s.rng.integers(0, pop_n, (2, n)); return np.where(better(i, j), i, j)
    def run(s):
        while s.evals < s.budget:
            e = s.evals; s.step(); s.gen += 1
            if s.evals == e: break
        return s
    def final(s): return s.dec(s.X)
    def result(s): return finalize(s.p, s.final())

class Archive:
    """External archive of non-dominated points with grid-density truncation."""
    def __init__(s, cap=100, div=10, rng=None): s.cap, s.div, s.rng, s.X, s.F = cap, div, rng or np.random.default_rng(0), None, None
    def add(s, X, F):
        XX, FF = (X, F) if s.X is None else (np.vstack([s.X, X]), np.vstack([s.F, F]))
        _, u = np.unique(FF.round(10), axis=0, return_index=True); XX, FF = XX[u], FF[u]
        f0 = nds(FF)[0]; XX, FF = XX[f0], FF[f0]
        while len(FF) > s.cap:
            c = s.counts(FF); k = s.rng.choice(np.where(c == c.max())[0]); XX, FF = np.delete(XX, k, 0), np.delete(FF, k, 0)
        s.X, s.F = XX, FF
    def cell(s, F):
        lo, hi = F.min(0), F.max(0); cid = ((F - lo) / (hi - lo + 1e-12) * s.div).astype(int).clip(0, s.div - 1)
        return np.ravel_multi_index(cid.T, (s.div,) * F.shape[1])
    def counts(s, F=None):
        F = s.F if F is None else F; key = s.cell(F); return np.bincount(key)[key]
    def pick(s, k, rng):
        """Leader selection favouring sparse grid cells (roulette on 1/count)."""
        p = 1.0 / s.counts(); return rng.choice(len(p), k, p=p / p.sum())
    def region_pick(s, k, rng):
        """PESA-II: binary tournament between regions (less crowded wins), then a random member."""
        key = s.cell(s.F); regs = np.unique(key); cnt = {r: (key == r).sum() for r in regs}; out = []
        for _ in range(k):
            a, b = rng.choice(regs, 2); r = a if cnt[a] <= cnt[b] else b; out.append(rng.choice(np.where(key == r)[0]))
        return np.array(out)

def env_select(F, CV, n):
    """NSGA-II survivor selection: fill by fronts, break the last front by crowding. Returns (selected, rank, crowd)."""
    fr = nds(F, CV); rank = np.zeros(len(F), int); crowd = np.zeros(len(F)); sel = []
    for k, f in enumerate(fr): rank[f] = k; crowd[f] = crowding(F[f])
    for f in fr:
        if len(sel) + len(f) <= n: sel += list(f)
        else: sel += list(f[np.argsort(-crowd[f])][:n - len(sel)])
        if len(sel) >= n: break
    return np.array(sel), rank, crowd
