# Cell 26: A2.18 MOEA/D and A2.19 MOEA/D-DE
class MOEADDE(MOEAD):
    """MOEA/D with DE/rand/1 variation: v = x_r1 + F (x_r2 - x_r3), binomial crossover CR=1, then polynomial mutation. F=0.5."""
    de = True
def ut_19():
    m = MOEADDE(P3, budget=300, seed=0, N=30, T=6).run(); assert (m.X >= P3.lb - 1e-12).all() and (m.X <= P3.ub + 1e-12).all() and m.de   # DE children stay in bounds
A2(19, cls_runner(MOEADDE), unit=ut_19)
