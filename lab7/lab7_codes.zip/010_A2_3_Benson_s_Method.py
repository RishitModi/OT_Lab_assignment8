# Cell 10: A2.3 Benson's Method
def benson(p, seed=0, n_start=12):
    """Steps: 1) feasible x0  2) max sum(l) s.t. f(x)+l=f(x0), l>=0 (equivalently min sum f s.t. f<=f(x0))  3) repeat for new x0."""
    rng = np.random.default_rng(seed); out = []; X0 = []
    while len(X0) < n_start:
        x = p.init(rng, 1)[0]
        if p.f(x)[1][0] <= 0: X0.append(x)
    for x0 in X0:
        F0 = _fn(p, x0)
        x = _solve(p, lambda x: _fn(p, x).sum(), rng, cons=[{"type": "ineq", "fun": lambda x, F0=F0: F0 - _fn(p, x)}], starts=2, x0=x0)
        if x is not None: out.append(x)
    return np.array(out)

def ut_3():
    X = benson(P1, 1, 5)
    for x in X: pass
    rng = np.random.default_rng(1); x0 = np.array([1.5]); F0 = _fn(P1, x0)
    x = _solve(P1, lambda x: _fn(P1, x).sum(), rng, cons=[{"type": "ineq", "fun": lambda x: F0 - _fn(P1, x)}], x0=x0)
    assert (_fn(P1, x) <= F0 + 1e-6).all()                   # result is at least as good as x0 in every objective
A2(3, lambda P, s, b: finalize(P, benson(P, s)), unit=ut_3)
