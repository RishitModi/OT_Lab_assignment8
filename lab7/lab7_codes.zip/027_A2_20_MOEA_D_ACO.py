# Cell 27: A2.20 MOEA/D-ACO
def build_tour(rng, W):
    """Probabilistic route construction from an attractiveness matrix."""
    n = len(W); cur = rng.integers(n); t = [cur]; vis = np.zeros(n, bool); vis[cur] = True
    for _ in range(n - 1):
        w = np.where(vis, 0, W[cur]); cur = rng.choice(n, p=w / w.sum()); t.append(cur); vis[cur] = True
    return np.array(t)

class MOEAD_ACO(MOEA):
    """Steps: 1) weights, neighbourhoods, one pheromone matrix per sub-problem  2) ant builds tour  3) update neighbours (Tchebycheff)  4) evaporate (rho) and deposit. N=20, T=4, rho=0.1, alpha=1, beta=2."""
    Ndef = 20; T = 4; rho = 0.1; alpha = 1.0; beta = 2.0; nr = 2
    def initialize(s):
        p = s.p; n = p.n; t = np.linspace(0, 1, s.N); s.W = np.c_[t, 1 - t]; s.B = np.argsort(cdist(s.W, s.W), 1)[:, :s.T]
        dn, tn = p.D / p.D.mean(), p.Tm / p.Tm.mean(); s.eta = np.array([1 / np.maximum(w[0] * dn + w[1] * tn, 1e-9) for w in s.W])
        for e in s.eta: np.fill_diagonal(e, 1e-12)
        s.tau = np.ones((s.N, n, n)); s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.z = s.F.min(0)
    def step(s):
        for i in range(s.N):
            t = build_tour(s.rng, (s.tau[i] ** s.alpha) * (s.eta[i] ** s.beta)); f = s.evaluate(t[None])[0]; s.z = np.minimum(s.z, f); c = 0
            for j in s.rng.permutation(s.B[i]):
                if tcheb(f, s.W[j], s.z) <= tcheb(s.F[j], s.W[j], s.z): s.X[j], s.F[j] = t, f; c += 1
                if c >= s.nr: break
        for i in range(s.N):
            s.tau[i] *= (1 - s.rho)
            for j in s.B[i]:
                t = s.X[j]; nx = np.roll(t, -1); d = 1 / (tcheb(s.F[j], s.W[i], s.z) + 0.05); s.tau[i][t, nx] += d; s.tau[i][nx, t] += d

def ut_20():
    a = MOEAD_ACO(P8, budget=100, seed=0, N=6, T=3); assert all(sorted(x) == list(range(15)) for x in a.X)      # every route visits each city once
    a.run(); assert all(sorted(x) == list(range(15)) for x in a.X)
A2(20, cls_runner(MOEAD_ACO), unit=ut_20)
