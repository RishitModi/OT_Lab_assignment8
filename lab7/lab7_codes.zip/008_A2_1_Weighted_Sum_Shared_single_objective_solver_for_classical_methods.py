# Cell 8: A2.1 Weighted Sum - Shared single-objective solver for classical methods (scipy allowed here)
# ---- Shared single-objective solver for classical methods (scipy allowed here) ----
def _solve(p, fun, rng, cons=(), starts=4, x0=None, aug=0):
    """Multi-start SLSQP of fun(y); y = [x, aug extra vars]; honours p.g (>=0) and bounds."""
    n = p.n; cs = list(cons)
    if p.g: cs.append({"type": "ineq", "fun": lambda y: p.g(y[:n])})
    bnds = list(zip(p.lb, p.ub)) + [(0, 10)] * aug; best = None
    for k in range(starts):
        y0 = p.lb + rng.random(n) * (p.ub - p.lb)
        if x0 is not None and k == 0: y0 = np.asarray(x0, float)
        r = minimize(fun, np.r_[y0, np.ones(aug)], method="SLSQP", bounds=bnds, constraints=cs, options={"maxiter": 150})
        if p.f(r.x[:n])[1][0] <= 1e-6 and np.isfinite(r.fun) and (best is None or r.fun < best.fun): best = r
    return None if best is None else best.x[:n]
_fn = lambda p, x: p.norm(p.f(x)[0])[0]          # normalized objective vector of one point

def weighted_sum(p, seed=0, n_w=11):
    """Steps: 1) pick w (sum 1)  2) minimize w·f  3) repeat for n_w weights. Returns decision vectors."""
    rng = np.random.default_rng(seed); out = []
    for w in np.linspace(0, 1, n_w):
        x = _solve(p, lambda x, wv=np.r_[w, 1 - w]: wv @ _fn(p, x), rng)
        if x is not None: out.append(x)
    return np.array(out)

def ut_1():
    X = weighted_sum(P1, 0, 3); F = P1.f(X)[0]
    assert abs(F[0, 1]) < 1e-3 and abs(F[-1, 0]) < 1e-3      # w=(0,1) -> x=7 (f2=0) ; w=(1,0) -> x=3 (f1=0)
    X = weighted_sum(P3, 0, 11); Fn = finalize(P3, X)
    assert ((Fn[:, 0] < 0.05) | (Fn[:, 0] > 0.95)).all()     # ZDT2 (non-convex): only the end points are found
A2(1, lambda P, s, b: finalize(P, weighted_sum(P, s)), unit=ut_1)
