# Cell 28: A2.21 Constrained NSGA-II
class CNSGA2(NSGA2):
    """NSGA-II steps with constrained-dominance (Deb's three rules) used by sorting, crowded comparison and survivor selection."""
    use_cv = True

def ut_21():
    sel, rank, _ = env_select(np.array([[5., 5.], [1., 1.], [2., 2.]]), np.array([0, 1., .5]), 1); assert sel[0] == 0       # feasible wins despite worse F
    sel, rank, _ = env_select(np.array([[5., 5.], [1., 1.], [2., 2.]]), np.array([0, 1., .5]), 3); assert list(sel) == [0, 2, 1]   # then smaller violation first
A2(21, cls_runner(CNSGA2), unit=ut_21)
