# Cell 44: A2.36 MGDA
def ut_36():
    assert np.allclose(min_norm(np.array([[1., 0], [0, 1.]])), [.5, .5])                    # orthogonal equal-length gradients -> equal weights
    g = np.random.default_rng(0).normal(size=(3, 5)); a = min_norm(g); d = a @ g
    assert abs(a.sum() - 1) < 1e-9 and (g @ d >= d @ d - 1e-3).all()                       # common descent: every task improves at rate >= ||d||^2
    G2 = np.array([[1., 1.], [-1., -1.]]); assert np.allclose(min_norm(G2) @ G2, 0)          # opposite gradients -> d=0 (Pareto stationary)
ut_36(); print("[36] MGDA: unit test passed")
pe, pm_, pg = toy_run("equal"), toy_run("mgda"), toy_run("gradnorm")
print("toy final x — equal:", pe[-1].round(3), " MGDA:", pm_[-1].round(3), " GradNorm:", pg[-1].round(3), "(Pareto set: x1 = x2, -3<=x1<=3)")
hE, _ = train_mtl("equal"); hM, _ = train_mtl("mgda"); hG, wG = train_mtl("gradnorm")
fig, ax = plt.subplots(1, 3, figsize=(14, 3.6))
ax[0].plot([-3, 3], [-3, 3], "k-", lw=3, alpha=.2, label="Pareto set")
for pth, lab in ((pe, "equal"), (pm_, "MGDA"), (pg, "GradNorm")): ax[0].plot(pth[:, 0], pth[:, 1], ".-", ms=2, label=lab)
ax[0].set_title("P13(a) toy paths"); ax[0].legend(fontsize=7)
for a_, k, t in ((ax[1], 0, "classification loss"), (ax[2], 1, "regression loss")):
    for h_, lab in ((hE, "equal"), (hM, "MGDA"), (hG, "GradNorm")): a_.semilogy(h_[:, k], label=lab)
    a_.set_title("P13(b) " + t); a_.legend(fontsize=7)
plt.tight_layout(); plt.show()
LOG.append(dict(idx=36, name="MGDA", prob="P13", budget=400, hv=np.nan, sp=np.nan, igd=np.nan, rt=0, status="works", n=0))
print("final losses (cls, reg): equal", hE[-1].round(3), "| MGDA", hM[-1].round(3), "| GradNorm", hG[-1].round(3))
