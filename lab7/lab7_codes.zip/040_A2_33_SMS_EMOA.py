# Cell 40: A2.33 SMS-EMOA
def contrib2d(F, ref):
    """Exact hypervolume contribution of every point of a 2-D non-dominated set."""
    o = np.argsort(F[:, 0]); P = np.minimum(F[o], ref); c = np.zeros(len(F))
    for k in range(len(P)):
        right = P[k + 1, 0] if k + 1 < len(P) else ref[0]; up = P[k - 1, 1] if k > 0 else ref[1]; c[o[k]] = max(0.0, (right - P[k, 0]) * (up - P[k, 1]))
    return c

def contrib_mc(F, ref, rng, S=4000):
    """Monte-Carlo contribution = volume dominated by this point only (3+ objectives)."""
    lo = np.minimum(F.min(0), ref - 1e-6); smp = rng.uniform(lo, ref, (S, F.shape[1])); dom = (F[None] <= smp[:, None]).all(2)
    return (dom & (dom.sum(1) == 1)[:, None]).sum(0) / S * np.prod(ref - lo)

class SMSEMOA(MOEA):
    """Steps: 1) population  2) one offspring (2 random parents)  3) sort union  4) delete the least-HV-contributor of the last front. N=100."""
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def step(s):
        i, j = s.rng.choice(len(s.X), 2, replace=False); off = s.offspring(s.X[[i, j]])[:1]; XU, FU = np.vstack([s.X, off]), np.vstack([s.F, s.evaluate(off)])
        last = nds(FU)[-1]; c = contrib2d(FU[last], s.p.ref) if s.p.m == 2 else contrib_mc(FU[last], s.p.ref, s.rng)
        keep = np.ones(len(FU), bool); keep[last[np.argmin(c)]] = False; s.X, s.F = XU[keep], FU[keep]

def ut_33():
    F = np.array([[1, 3], [2, 2], [3, 1.]]); c = contrib2d(F, np.array([4., 4.])); assert np.allclose(c, [1, 1, 1])   # staircase: each point owns a unit square
    assert abs(contrib2d(np.array([[1, 3], [2, 2.], [2.1, 2.]]), np.array([4., 4.]))[1]) < 0.3
A2(33, cls_runner(SMSEMOA), unit=ut_33)
