# Cell 41: A2.34 HypE
class HypE(MOEA):
    """Steps: 1) mating, offspring  2) sample S points in the box [min F, ref]  3) HypE fitness with weights alpha_c  4) remove the worst in chunks and recompute. N=50, S=2000."""
    Ndef = 50; S = 2000; chunk = 10
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def fitness(s, F, k):
        ref = s.p.ref; lo = np.minimum(F.min(0), ref - 1e-6); smp = s.rng.uniform(lo, ref, (s.S, F.shape[1])); dom = (F[None] <= smp[:, None]).all(2); P = len(F); al = np.zeros(P + 1)
        for c in range(1, P + 1):
            a = 1.0
            for j in range(1, c): a *= max(k - j, 0) / (P - j)
            al[c] = a / c
        return (dom * al[dom.sum(1)][:, None]).sum(0) * np.prod(ref - lo) / s.S
    def select(s, F, n):
        act = np.arange(len(F))
        while len(act) > n:
            k = len(act) - n; fit = s.fitness(F[act], k); act = np.delete(act, np.argsort(fit)[:min(s.chunk, k)])
        return act
    def step(s):
        off = s.offspring(s.X[s.rng.permutation(len(s.X))]); XU, FU = np.vstack([s.X, off]), np.vstack([s.F, s.evaluate(off)]); sel = s.select(FU, s.N); s.X, s.F = XU[sel], FU[sel]

def ut_34():
    m = HypE(P10_3, budget=10 ** 6, seed=0, N=10, S=20000); F = np.array([[.1, .1, .1], [.5, .5, .5], [1., 1., 1.]]); fit = m.fitness(F, 1)
    assert fit[1] == 0 and fit[0] > 0                                                     # k=1: only exclusive volume counts, a dominated point has none
A2(34, cls_runner(HypE), unit=ut_34)
