# Cell 30: A2.23 MOGWO
class MOGWO(MOEA):
    """Steps: 1) init pack + archive  2) pick alpha,beta,delta from archive  3) a=2(1-t/T); A=2a r1-a; C=2 r2  4) X=(X1+X2+X3)/3  5) archive update. N=50, cap=100."""
    Ndef = 50; swarm = True; cap = 100
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.A = Archive(s.cap, 10, s.rng); s.A.add(s.X, s.F)
    def step(s):
        a = 2 * (1 - s.evals / s.budget); L = s.A.X[s.A.pick(3, s.rng)]; Xn = 0
        for k in range(3):
            A = 2 * a * s.rng.random(s.X.shape) - a; C = 2 * s.rng.random(s.X.shape); Xn = Xn + (L[k] - A * np.abs(C * L[k] - s.X)) / 3
        s.X = np.clip(Xn, s.p.lb, s.p.ub); s.F = s.evaluate(s.X); s.A.add(s.X, s.F)
    def final(s): return s.dec(s.A.X)

def ut_23():
    m = MOGWO(P5, budget=10 ** 6, seed=0, N=20); m.step(); assert (m.X >= P5.lb).all() and (m.X <= P5.ub).all() and len(nds(m.A.F)[0]) == len(m.A.F)
    assert 2 * (1 - 0 / 100) == 2 and 2 * (1 - 100 / 100) == 0                           # coefficient a shrinks 2 -> 0 (explore -> exploit)
A2(23, cls_runner(MOGWO), unit=ut_23)
