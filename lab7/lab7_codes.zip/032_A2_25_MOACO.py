# Cell 32: A2.25 MOACO
class MOACO(MOEA):
    """Steps: 1) tau1, tau2, eta1=1/d, eta2=1/t  2) each ant: random lambda, probabilistic tour  3) evaluate, archive  4) evaporate (rho), deposit from archive. ants=20, rho=0.1, alpha=1, beta=2."""
    Ndef = 20; rho = 0.1; alpha = 1.0; beta = 2.0; cap = 100
    def initialize(s):
        n = s.p.n; s.t1, s.t2 = np.ones((n, n)), np.ones((n, n)); s.e1, s.e2 = 1 / s.p.D, 1 / s.p.Tm
        for e in (s.e1, s.e2): np.fill_diagonal(e, 1e-12)
        s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.A = Archive(s.cap, 10, s.rng); s.A.add(s.X, s.F)
    def step(s):
        T = [build_tour(s.rng, ((s.t1 ** l) * (s.t2 ** (1 - l))) ** s.alpha * ((s.e1 ** l) * (s.e2 ** (1 - l))) ** s.beta) for l in s.rng.random(s.N)]
        s.X = np.array(T); s.F = s.evaluate(s.X); s.A.add(s.X, s.F); s.t1 *= 1 - s.rho; s.t2 *= 1 - s.rho
        for t, f in zip(s.A.X, s.A.F):
            nx = np.roll(t, -1); d1, d2 = 1 / (f[0] + .05), 1 / (f[1] + .05); s.t1[t, nx] += d1; s.t1[nx, t] += d1; s.t2[t, nx] += d2; s.t2[nx, t] += d2
    def final(s): return s.A.X

def ut_25():
    m = MOACO(P8, budget=10 ** 6, seed=0, N=8); t1 = m.t1.copy(); m.step()
    assert all(sorted(x) == list(range(15)) for x in m.X) and np.allclose(m.t1, m.t1.T) and m.t1.max() > 1 and m.t1.min() < 1   # valid tours; deposit and evaporation both happened
A2(25, cls_runner(MOACO), unit=ut_25)
