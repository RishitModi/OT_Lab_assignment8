# Cell 6: A1. Shared toolkit (moo_utils) - Sanity checks from the PDF (verified by hand)
# ---- Sanity checks from the PDF (verified by hand) ----
assert np.allclose(P1.f(np.array([5.]))[0], [[4, 4]]) and np.allclose(P2.f(np.array([2.]))[0], [[50, 4]])
assert np.allclose(P3.f(np.r_[.5, np.zeros(9)])[0], [[.5, .75]])
assert np.allclose(P4.f(np.array([0, 0, 1, 0.]))[0], [[.09, -.15]])
F5, C5 = P5.f(np.array([.01, .05])); assert np.allclose(F5, [[3.925, .016]]) and C5[0] == 0
assert np.allclose(P6.f(np.array([0, 0.]))[0], [[0, 50]]) and np.allclose(P6.f(np.array([5, 3.]))[0], [[136, 4]])
assert np.allclose(P7.f(np.array([10, 80.]))[0], [[-8, -96]]) and np.allclose(P14.f(np.array([13, 40.]))[0][0, 0], 1.53)
assert abs(-P14.f(np.array([13, 40.]))[0][0, 1] - 9.0) < 0.02
assert np.allclose((P10_3.pf ** 2).sum(1), 1)
rr = np.random.default_rng(0); Xr = P5.init(rr, 20000); print("P5 infeasible fraction of random designs: %.2f" % (P5.f(Xr)[1] > 0).mean())
print("P8 cities (seed 7):\n", CITY.round(2).tolist()); print("P9 all-ones baseline CV error: %.3f" % BASE_ERR)
print("All problem sanity checks passed")
