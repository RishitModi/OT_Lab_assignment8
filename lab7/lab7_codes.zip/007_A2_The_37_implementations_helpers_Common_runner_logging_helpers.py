# Cell 7: A2. The 37 implementations — helpers - Common runner / logging helpers
# ---- Common runner / logging helpers ----
LOG = []
def finalize(p, X):
    """Evaluate a decision set, keep feasible non-dominated points -> normalized objectives."""
    if X is None or len(X) == 0: return np.empty((0, p.m))
    F, CV = p.f(np.asarray(X)); Fn = p.norm(F[CV <= 1e-9])
    if len(Fn) == 0: return Fn
    Fn = Fn[nds(Fn)[0]]; return np.unique(Fn.round(12), axis=0)

def metrics(p, Fn):
    return hv(Fn, p.ref), spacing(Fn), (igd(p.pf_n, Fn) if p.pf_n is not None else np.nan)

def A2(idx, runner, probs=None, unit=None, status="works"):
    """Run the unit test, run the algorithm on its test problems with a fixed seed, plot and log metrics."""
    if unit: unit(); print(f"[{idx}] {NAME[idx]}: unit test passed")
    probs = probs or TESTS[idx]; fig, axs = plt.subplots(1, len(probs), figsize=(4.4 * len(probs), 3.5), squeeze=False)
    for ax, pn in zip(axs[0], probs):
        P = PROBS[pn]; b = BUDGET_MANY if P.m > 2 else BUDGET; t = time.time(); Fn = runner(P, SEED0, b); rt = time.time() - t
        h, sp, ig = metrics(P, Fn); R = P.denorm(Fn) if len(Fn) else Fn
        LOG.append(dict(idx=idx, name=NAME[idx], prob=pn, budget=b, hv=h, sp=sp, igd=ig, rt=rt, status=status, n=len(Fn)))
        if P.pf is not None: ax.plot(P.pf[:, 0], P.pf[:, 1], "k.", ms=2, label="true front")
        if len(R): ax.scatter(R[:, 0], R[:, 1], s=14, c="C3", label=f"{NAME[idx]} ({len(R)})")
        ax.set_title(f"{pn}: HV={h:.3f} IGD={ig:.3f}" if not np.isnan(ig) else f"{pn}: HV={h:.3f}", fontsize=9); ax.legend(fontsize=7)
    plt.tight_layout(); plt.show()

def cls_runner(cls, **kw):
    """Runner for population-based algorithms (defined later)."""
    return lambda P, seed, b: cls(P, budget=b, seed=seed, **kw).run().result()
