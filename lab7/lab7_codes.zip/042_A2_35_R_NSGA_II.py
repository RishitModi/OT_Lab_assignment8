# Cell 42: A2.35 R-NSGA-II
def eps_clear(F, order, eps):
    """Walk the preference order; points closer than eps to an already kept point are moved to the back."""
    left, out, later = list(order), [], []
    while left:
        a = left.pop(0); out.append(a); keep = []
        for b in left: (later if np.linalg.norm(F[a] - F[b]) < eps else keep).append(b)
        left = keep
    return np.array(out + later)

class RNSGA2(NSGA2):
    """NSGA-II with preference: survivors of the last front are ordered by distance to the reference point (normalized), eps-clearing eps=0.02. ref_pt in raw (minimization) units."""
    eps = 0.02; ref_pt = None
    def initialize(s):
        s.zn = s.p.norm(np.asarray(s.ref_pt if s.ref_pt is not None else s.p.pref, float)[None])[0]; NSGA2.initialize(s)
    def survive(s, F, CV, n):
        fr = nds(F); rank = np.zeros(len(F), int); crowd = np.zeros(len(F)); sel = []
        for k, f in enumerate(fr):
            order = eps_clear(F[f], np.argsort(np.linalg.norm(F[f] - s.zn, axis=1)), s.eps); pr = np.empty(len(f)); pr[order] = np.arange(len(f)); rank[f] = k; crowd[f] = -pr
            if len(sel) < n: sel += list(f[order][:n - len(sel)])
        return np.array(sel), rank, crowd

def ut_35():
    F = np.array([[0, 0], [0.001, 0], [1, 1.]]); assert list(eps_clear(F, [0, 1, 2], 0.01)) == [0, 2, 1]       # near-duplicate pushed behind
def run_35(P, s, b):
    a = RNSGA2(P, budget=b, seed=s).run(); Fn = a.result(); d = np.linalg.norm(Fn - a.zn, axis=1); print(f"  {P.name}: closest front point to reference is {d.min():.3f} (normalized)"); return Fn
A2(35, run_35, unit=ut_35)
