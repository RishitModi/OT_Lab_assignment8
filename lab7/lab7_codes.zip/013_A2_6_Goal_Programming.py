# Cell 13: A2.6 Goal Programming
def goal_programming(lin, targets, w, senses=(">=", ">=")):
    """Steps: 1) targets  2) add d-,d+  3) minimize sum w*d (d- for '>=' goals, d+ for '<=')  4) solve LP."""
    C, A, b = lin["C"], lin["A"], lin["b"]; m, n = C.shape
    c = np.r_[np.zeros(n), [w[i] if senses[i] in (">=", "=") else 0 for i in range(m)], [w[i] if senses[i] in ("<=", "=") else 0 for i in range(m)]]
    r = linprog(c, A_ub=np.hstack([A, np.zeros((len(A), 2 * m))]), b_ub=b, A_eq=np.hstack([C, np.eye(m), -np.eye(m)]), b_eq=targets,
                bounds=list(zip(lin["lb"], lin["ub"])) + [(0, None)] * (2 * m), method="highs")
    return r.x[:n], r.x[n:n + m], r.x[n + m:]

def ut_6():
    x, dm, dp = goal_programming(P11.lin, [2400, 600], [1, 1])
    assert abs(dm[1] - 100) < 1e-6 and dm[0] < 1e-6          # units goal 600 unreachable -> shortfall exactly 100; profit met
def run_6(P, s, b):
    lin = P.lin; T = {"P11": [2400, 600], "P7": [40, 50]}[P.name]; sols = []
    for lab, w in [("unit weights", [1, 1]), ("normalized 1/T", [1 / T[0], 1 / T[1]])]:
        x, dm, dp = goal_programming(lin, T, w); sols.append(x); print(f"  {P.name} {lab}: x={x.round(2)}, shortfall d-={dm.round(2)}")
    return finalize(P, np.array(sols))
A2(6, run_6, unit=ut_6)
