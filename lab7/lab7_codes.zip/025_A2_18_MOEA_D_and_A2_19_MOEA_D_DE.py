# Cell 25: A2.18 MOEA/D and A2.19 MOEA/D-DE
class MOEAD(MOEA):
    """Steps: 1) weight vectors + T-neighbourhoods  2) pick parents from neighbourhood (prob delta)  3) variation  4) update ideal z*  5) replace up to nr neighbours if Tchebycheff improves. T=20, delta=0.9, nr=2."""
    T = 20; delta = 0.9; nr = 2; de = False; Fde = 0.5; CR = 1.0
    def initialize(s):
        M = s.p.m; s.W = np.c_[np.linspace(0, 1, s.N), 1 - np.linspace(0, 1, s.N)] if M == 2 else das_dennis(M, {3: 12, 5: 6}.get(M, 4)); s.N = len(s.W)
        s.B = np.argsort(cdist(s.W, s.W), 1)[:, :min(s.T, s.N)]; s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.z = s.F.min(0)
    def step(s):
        for i in s.rng.permutation(s.N):
            pool = s.B[i] if s.rng.random() < s.delta else np.arange(s.N)
            if s.de:
                r = s.rng.choice(pool, 3, replace=len(pool) < 3); v = s.X[r[0]] + s.Fde * (s.X[r[1]] - s.X[r[2]])
                m = s.rng.random(s.p.n) < s.CR; m[s.rng.integers(s.p.n)] = True; c = s.mutate(s.repair(np.where(m, v, s.X[i])[None]))
            else:
                a, b = s.rng.choice(pool, 2, replace=False); c = s.offspring(s.X[[a, b]])[:1]
            fc = s.evaluate(c)[0]; s.z = np.minimum(s.z, fc); cnt = 0
            for j in s.rng.permutation(pool):
                if tcheb(fc, s.W[j], s.z) <= tcheb(s.F[j], s.W[j], s.z): s.X[j], s.F[j] = c[0], fc; cnt += 1
                if cnt >= s.nr: break
            if s.evals >= s.budget: break

def ut_18():
    z = np.zeros(2); assert tcheb(np.array([.2, .2]), np.array([.5, .5]), z) < tcheb(np.array([.4, .4]), np.array([.5, .5]), z)
    m = MOEAD(P3, budget=50, seed=0, N=20, T=5); assert all(i in m.B[i] for i in range(m.N)) and m.B.shape == (20, 5)   # each sub-problem is in its own neighbourhood
A2(18, cls_runner(MOEAD), unit=ut_18)
