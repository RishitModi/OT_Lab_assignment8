# Cell 34: A2.27 MODE
class MODE(MOEA):
    """Steps: 1) population  2) v=x_r1+F(x_r2-x_r3)  3) binomial crossover CR  4) trial replaces target only if it dominates. N=100, F=0.5, CR=0.9."""
    swarm = True; Fm = 0.5; CR = 0.9
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def step(s):
        N = s.N; r = np.array([s.rng.choice(N, 3, replace=False) for _ in range(N)]); V = s.X[r[:, 0]] + s.Fm * (s.X[r[:, 1]] - s.X[r[:, 2]])
        m = s.rng.random(s.X.shape) < s.CR; m[np.arange(N), s.rng.integers(0, s.p.n, N)] = True; U = np.clip(np.where(m, V, s.X), s.p.lb, s.p.ub)
        Fu = s.evaluate(U); b = (Fu <= s.F).all(1) & (Fu < s.F).any(1); s.X[b], s.F[b] = U[b], Fu[b]

def ut_27():
    m = MODE(P3, budget=10 ** 6, seed=0, N=30); Fb = m.F.copy(); m.step(); assert (m.F <= Fb + 1e-12).all()      # a target never gets worse in any objective
A2(27, cls_runner(MODE), unit=ut_27)
