# Cell 31: A2.24 MOABC
class MOABC(MOEA):
    """Steps: 1) food sources  2) employed phase v=x+phi(x-x_k) (one dim), keep if v dominates x  3) onlookers (prob ~ 1/(1+rank))  4) scouts after `limit` fails  5) archive. N=40, limit=10."""
    Ndef = 40; swarm = True; limit = 10; cap = 100
    def initialize(s):
        s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.trial = np.zeros(s.N, int); s.A = Archive(s.cap, 10, s.rng); s.A.add(s.X, s.F)
    def attempt(s, idx):
        n = len(idx); k = (idx + s.rng.integers(1, s.N, n)) % s.N; j = s.rng.integers(0, s.p.n, n); V = s.X[idx].copy(); r = np.arange(n)
        V[r, j] = s.X[idx, j] + s.rng.uniform(-1, 1, n) * (s.X[idx, j] - s.X[k, j]); V = np.clip(V, s.p.lb, s.p.ub); Fv = s.evaluate(V); s.A.add(V, Fv)
        for t, i in enumerate(idx):
            if (Fv[t] <= s.F[i]).all() and (Fv[t] < s.F[i]).any(): s.X[i], s.F[i], s.trial[i] = V[t], Fv[t], 0
            else: s.trial[i] += 1
    def step(s):
        s.attempt(np.arange(s.N)); rank = np.zeros(s.N)
        for k, f in enumerate(nds(s.F)): rank[f] = k
        p = 1 / (1 + rank); s.attempt(s.rng.choice(s.N, s.N, p=p / p.sum())); sc = np.where(s.trial > s.limit)[0]
        if len(sc): s.X[sc] = s.newpop(len(sc)); s.F[sc] = s.evaluate(s.X[sc]); s.trial[sc] = 0; s.A.add(s.X[sc], s.F[sc])
    def final(s): return s.dec(s.A.X)

def ut_24():
    m = MOABC(P3, budget=10 ** 6, seed=0, N=20, limit=2); Fb = m.F.copy(); m.attempt(np.arange(20))
    assert all(((m.F[i] <= Fb[i]).all()) for i in range(20))                              # greedy: a source only ever moves to a dominating point
    m.trial[:] = 5; m.step(); assert (m.trial <= 5).all() and m.trial.min() == 0         # scouts reset exhausted sources
A2(24, cls_runner(MOABC), unit=ut_24)
