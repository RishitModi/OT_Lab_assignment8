# Cell 52: D1. Continuous bi-objective: P3 (unconstrained) and P5 (constrained)
D1_IDS = [1, 2, 3, 4] + [i for i in range(10, 36) if i not in (20, 25)]
for pn in ("P3", "P5"):
    t0 = time.time()
    for i in D1_IDS: run_many(i, runner_for(i, pn), pn)
    rows = rtab(pn, D1_IDS, f"Ranking on {pn} ({'constrained' if pn == 'P5' else 'unconstrained'}), budget {BUDGET}, {RUNS} seeds"); print(f"{pn} done in {time.time() - t0:.0f}s")
    plot_fronts(pn, rows[:12], f"{pn}: fronts of the 12 best algorithms (seed {SEED0})")
