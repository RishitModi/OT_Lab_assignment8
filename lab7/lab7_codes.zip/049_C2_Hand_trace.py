# Cell 49: C2. Hand trace
def hand_trace(idx):
    np.set_printoptions(precision=4, suppress=True); print(f"===== Hand trace of [{idx}] {NAME[idx]} =====")
    if idx in CLS:
        P = P8 if idx in (20, 25) else P1; a = CLS[idx](P, budget=10 ** 6, seed=0, N=4) if idx not in (15, 31) else CLS[idx](P, budget=10 ** 6, seed=0, div=3)
        for g in range(3):
            if g: a.step(); a.gen += 1
            print(f"-- generation {g} ({'initial' if g == 0 else 'after step'}): x ->  objectives (normalized)")
            for x, f in zip(a.X[:6], a.F[:6]): print("   ", np.asarray(x).round(3).ravel() if P is P1 else list(map(int, x))[:8], "->", f)
    else:
        tr = {1: lambda: weighted_sum(P1, 0, 2), 2: lambda: eps_constraint(P1, 0, 2), 3: lambda: benson(P1, 0, 2), 4: lambda: weight_metric(P1, 0, np.inf, 2),
              5: lambda: value_function(P1, 0, (0.3, 0.7))}
        if idx in tr:
            X = tr[idx](); print("two settings -> x:", X.ravel(), " objectives:", P1.f(X)[0].round(4).tolist())
        elif idx == 6: print("goal programming (targets 2400, 600):", [goal_programming(P11.lin, [2400, 600], w)[0] for w in ([1, 1], [1, 3])])
        elif idx == 7: print("lexicographic orders:", lexicographic(P11.lin, [0, 1]), lexicographic(P11.lin, [1, 0]))
        elif idx in (8, 9):
            M = np.array([[1., 10.], [2., 5.], [3., 1.]]); w = np.array([.5, .5]); bn = np.array([False, True]); print("3 alternatives:", M.tolist())
            print("TOPSIS closeness:" if idx == 8 else "VIKOR Q:", (topsis(M, w, bn) if idx == 8 else vikor(M, w, bn)).round(4))
        else:
            print("toy path, first 3 steps:", toy_run("mgda" if idx == 36 else "gradnorm")[:4].tolist())
for i in DEEP: hand_trace(i)
