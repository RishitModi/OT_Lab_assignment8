# Cell 9: A2.2 ε-Constraint
def eps_constraint(p, seed=0, n_eps=11):
    """Steps: 1) choose eps in [ideal,nadir] of f1  2) min f2 s.t. f1<=eps  3) sweep eps."""
    rng = np.random.default_rng(seed); out = []
    for e in np.linspace(0, 1, n_eps):
        x = _solve(p, lambda x: _fn(p, x)[1], rng, cons=[{"type": "ineq", "fun": lambda x, e=e: e - _fn(p, x)[0]}])
        if x is not None: out.append(x)
    return np.array(out)

def ut_2():
    X = eps_constraint(P1, 0, 3); F = P1.f(X)[0]
    assert abs(F[0, 0]) < 1e-3                               # eps=0 forces f1 = 0 (x = 3)
    Fn = finalize(P3, eps_constraint(P3, 0, 11)); assert ((Fn[:, 0] > 0.05) & (Fn[:, 0] < 0.95)).any()   # reaches the middle of ZDT2
A2(2, lambda P, s, b: finalize(P, eps_constraint(P, s)), unit=ut_2)
