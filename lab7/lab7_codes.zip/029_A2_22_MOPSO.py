# Cell 29: A2.22 MOPSO
class MOPSO(MOEA):
    """Steps: 1) init swarm, archive  2) leader from archive (grid roulette)  3) velocity+position update  4) mutation (10%)  5) pbest by dominance  6) archive update. N=50, w=0.4, c1=c2=1.5, cap=100."""
    Ndef = 50; swarm = True; w = 0.4; c1 = 1.5; c2 = 1.5; cap = 100; pm = 0.1
    def initialize(s):
        s.X = s.newpop(s.N); s.F = s.evaluate(s.X); s.V = np.zeros_like(s.X); s.PB, s.PF = s.X.copy(), s.F.copy()
        s.A = Archive(s.cap, 10, s.rng); s.A.add(s.X, s.F)
    def step(s):
        L = s.A.X[s.A.pick(s.N, s.rng)]; r1, r2 = s.rng.random((2,) + s.X.shape); rg = s.p.ub - s.p.lb
        s.V = np.clip(s.w * s.V + s.c1 * r1 * (s.PB - s.X) + s.c2 * r2 * (L - s.X), -.5 * rg, .5 * rg); s.X = np.clip(s.X + s.V, s.p.lb, s.p.ub)
        mm = s.rng.random(s.N) < s.pm; s.X[mm] = polymut(s.rng, s.X[mm], s.p.lb, s.p.ub, pm=0.5) if mm.any() else s.X[mm]
        s.F = s.evaluate(s.X); nd = lambda a, b: (a <= b).all(1) & (a < b).any(1)
        upd = nd(s.F, s.PF) | (~nd(s.PF, s.F) & (s.rng.random(s.N) < .5)); s.PB[upd], s.PF[upd] = s.X[upd], s.F[upd]; s.A.add(s.X, s.F)
    def final(s): return s.dec(s.A.X)

def ut_22():
    m = MOPSO(P4, budget=10 ** 6, seed=0, N=10, w=0, c1=0, c2=0, pm=0); X0 = m.X.copy(); m.step(); assert np.allclose(m.X, X0)   # no inertia/attraction -> no movement
    m = MOPSO(P4, budget=10 ** 6, seed=0, N=20); [m.step() for _ in range(5)]; assert len(nds(m.A.F)[0]) == len(m.A.F)          # archive is mutually non-dominated
A2(22, cls_runner(MOPSO), unit=ut_22)
