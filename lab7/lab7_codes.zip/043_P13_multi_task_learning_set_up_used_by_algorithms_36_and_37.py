# Cell 43: P13 — multi-task learning set-up (used by algorithms 36 and 37)
def min_norm(G):
    """Min-norm point of the convex hull of the rows of G (Frank-Wolfe); alpha on the simplex."""
    M = len(G)
    if M == 2:
        d = G[0] - G[1]; a = np.clip(((G[1] - G[0]) @ G[1]) / (d @ d + 1e-18), 0, 1); return np.array([a, 1 - a])
    a = np.ones(M) / M; Gm = G @ G.T
    for _ in range(3000):
        t = np.argmin(Gm @ a); dd = np.eye(M)[t] - a; den = dd @ Gm @ dd
        if den <= 1e-18: break
        a = a + np.clip(-(dd @ Gm @ a) / den, 0, 1) * dd
    return a

def gradnorm_update(w, L, L0, gn, alpha=1.5, eta=0.01):
    """GradNorm: push each task's weighted gradient norm G_i=w_i*||g_i|| toward mean(G)*r_i^alpha (r_i = relative inverse training rate)."""
    G = w * gn; r = (L / L0) / (L / L0).mean(); tgt = G.mean() * r ** alpha; w = np.clip(w * np.exp(-eta * np.sign(G - tgt)), 0.3, None); return len(w) * w / w.sum()

A_, B_ = np.array([3., 3.]), np.array([-3., -3.])
def toy_run(method, x0=(0., 5.), lr=0.05, iters=150):
    x = np.array(x0); w = np.ones(2); path = [x.copy()]; L0 = np.array([((x - A_) ** 2).sum(), ((x - B_) ** 2).sum()])
    for _ in range(iters):
        g = np.array([2 * (x - A_), 2 * (x - B_)]); L = np.array([((x - A_) ** 2).sum(), ((x - B_) ** 2).sum()])
        if method == "equal": d = g.sum(0)
        elif method == "mgda": d = 2 * (min_norm(g) @ g)
        else: w = gradnorm_update(w, L, L0, np.linalg.norm(g, axis=1)); d = w @ g
        x = x - lr * d; path.append(x.copy())
    return np.array(path)

def make_mtl_data(rng, n=300):
    X = rng.normal(size=(n, 5)); return X, (X[:, 0] + X[:, 1] > 0).astype(float), 20 * (X[:, 2] - .5 * X[:, 3])   # regression target has a large scale

def init_net(rng, h=12): return dict(W1=rng.normal(0, .3, (5, h)), b1=np.zeros(h), wc=rng.normal(0, .3, h), bc=np.zeros(1), wr=rng.normal(0, .3, h), br=np.zeros(1))

def net_grads(P, X, yc, yr):
    """Forward + manual backward: returns losses (cls, reg), shared-body gradients per task, head gradients per task."""
    n = len(X); H = np.tanh(X @ P["W1"] + P["b1"]); pc = 1 / (1 + np.exp(-(H @ P["wc"] + P["bc"][0]))); pr = H @ P["wr"] + P["br"][0]
    Lc = -np.mean(yc * np.log(pc + 1e-12) + (1 - yc) * np.log(1 - pc + 1e-12)); Lr = np.mean((pr - yr) ** 2); dzc, dpr = (pc - yc) / n, 2 * (pr - yr) / n
    sh = lambda dz, w: (lambda dA: np.r_[(X.T @ dA).ravel(), dA.sum(0)])(np.outer(dz, w) * (1 - H ** 2))
    return (Lc, Lr), (sh(dzc, P["wc"]), sh(dpr, P["wr"])), (dict(wc=H.T @ dzc, bc=np.array([dzc.sum()])), dict(wr=H.T @ dpr, br=np.array([dpr.sum()])))

def train_mtl(method, seed=0, epochs=400, lr=0.002):
    rng = np.random.default_rng(seed); X, yc, yr = make_mtl_data(rng); P = init_net(rng); w = np.ones(2); L0 = None; hist = []; h = P["b1"].size
    for _ in range(epochs):
        L, (gc, gr), (hc, hr) = net_grads(P, X, yc, yr); L = np.array(L); L0 = L.copy() if L0 is None else L0; hist.append(L)
        if method == "equal": d = gc + gr
        elif method == "mgda": d = 2 * (min_norm(np.array([gc, gr])) @ np.array([gc, gr]))
        else: w = gradnorm_update(w, L, L0, np.array([np.linalg.norm(gc), np.linalg.norm(gr)])); d = w[0] * gc + w[1] * gr
        P["W1"] -= lr * d[:5 * h].reshape(5, h); P["b1"] -= lr * d[5 * h:]
        sc = w if method == "gradnorm" else np.ones(2)
        for k, v in hc.items(): P[k] -= lr * sc[0] * v
        for k, v in hr.items(): P[k] -= lr * sc[1] * v
    return np.array(hist), w
