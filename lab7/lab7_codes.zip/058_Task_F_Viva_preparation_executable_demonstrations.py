# Cell 58: Task F — Viva preparation: executable demonstrations
# Q3 / Q7: hypervolume history of an elitist (NSGA-II) vs a non-elitist (NSGA) algorithm; plateau = convergence/stagnation signal
def hv_curve(cls, P, budget, seed, every=5):
    a = cls(P, budget=budget, seed=seed); h = []
    while a.evals < budget:
        a.step(); a.gen += 1
        if a.gen % every == 0: Fcur = P.norm(P.f(a.dec(a.X))[0]); Fcur = Fcur[nds(Fcur)[0]]; h.append(hv(Fcur, P.ref))
    return np.array(h)
hN2, hN = hv_curve(NSGA2, P3, BUDGET, 1), hv_curve(NSGA, P3, BUDGET, 1)
fig, ax = plt.subplots(figsize=(5, 3.2)); ax.plot(hN2, label="NSGA-II (elitist)"); ax.plot(hN, label="NSGA (non-elitist)"); ax.set_xlabel("checkpoint (5 generations)"); ax.set_ylabel("HV of current population"); ax.legend(); plt.show()
dd = np.diff(hN); print(f"NSGA-II HV never decreases: {bool((np.diff(hN2) >= -1e-9).all())} | NSGA decreased {int((dd < -1e-9).sum())} times (no elitism)")
plateau = lambda h, k=5, tol=1e-4: len(h) > k and (h[-1] - h[-k] < tol); print("plateau test (last 5 checkpoints improve < 1e-4):", "NSGA-II", plateau(hN2), "| NSGA", plateau(hN))
