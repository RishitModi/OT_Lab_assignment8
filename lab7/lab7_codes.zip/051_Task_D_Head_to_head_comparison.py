# Cell 51: Task D — Head-to-head comparison
RES = {}
def run_many(idx, runner, pn, budget=None):
    """Run one algorithm on one problem for all seeds; store metrics and the first front in RES[(pn, idx)]."""
    P = PROBS[pn]; b = budget or (BUDGET_MANY if P.m > 2 else BUDGET); H, S_, G, rt = [], [], [], []; front = None
    for r in range(RUNS):
        t = time.time(); Fn = runner(P, SEED0 + r, b); rt.append(time.time() - t); h, sp, ig = metrics(P, Fn); H.append(h); S_.append(sp); G.append(ig)
        front = Fn if front is None else front
    RES[(pn, idx)] = dict(hv=H, sp=S_, igd=G, front=front, rt=np.mean(rt))
def rtab(pn, ids, title):
    """Ranked table (by mean HV, ties by IGD) for the algorithms of one experiment."""
    rows = sorted(ids, key=lambda i: (-round(np.mean(RES[(pn, i)]["hv"]), 3), np.nan_to_num(np.nanmean(RES[(pn, i)]["igd"]), nan=0))); out = []   # HV first, IGD breaks ties

    for k, i in enumerate(rows, 1):
        r = RES[(pn, i)]; ig = np.nanmean(r["igd"]); out.append((k, i, NAME[i], f"{np.mean(r['hv']):.4f} ± {np.std(r['hv']):.4f}", f"{np.nanmean(r['sp']):.4f} ± {np.nanstd(r['sp']):.4f}",
                                                                  "-" if np.isnan(ig) else f"{ig:.4f} ± {np.nanstd(r['igd']):.4f}", f"{r['rt']:.1f}s"))
    display(Markdown(f"**{title}**")); table(out, ["Rank", "#", "Algorithm", "HV (↑)", "Spacing (↓)", "IGD (↓)", "Runtime"]); return rows
def plot_fronts(pn, ids, title, ncol=4):
    P = PROBS[pn]; n = len(ids); nr = int(np.ceil(n / ncol)); fig, axs = plt.subplots(nr, ncol, figsize=(3.4 * ncol, 2.8 * nr), squeeze=False)
    for ax, i in zip(axs.ravel(), ids):
        F = RES[(pn, i)]["front"]; R = P.denorm(F) if len(F) else F
        if P.pf is not None: ax.plot(P.pf[:, 0], P.pf[:, 1], "k.", ms=1)
        if len(R): ax.scatter(R[:, 0], R[:, 1], s=6, c="C3")
        ax.set_title(f"[{i}] {NAME[i]}", fontsize=8)
    for ax in axs.ravel()[n:]: ax.axis("off")
    fig.suptitle(title); plt.tight_layout(); plt.show()

def runner_for(i, pn):
    P = PROBS[pn]
    if i == 35: pt = P.pref if P.pref is not None else np.array([0.3, 0.7]); return lambda P_, s, b: RNSGA2(P_, budget=b, seed=s, ref_pt=pt).run().result()
    if i >= 10: return cls_runner(CLS[i])
    sweep = {1: weighted_sum, 2: eps_constraint, 3: benson}
    if i == 4: return lambda P_, s, b: finalize(P_, weight_metric(P_, s, np.inf, 11))
    return lambda P_, s, b: finalize(P_, sweep[i](P_, s))
