# Cell 17: A2.10 VEGA
class VEGA(MOEA):
    """Steps: 1) split into M sub-populations, sub-population m selected by tournament on f_m  2) shuffle  3) crossover+mutation. Default N=100."""
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def subpops(s):
        M = s.F.shape[1]; out = []
        for m in range(M):
            i, j = s.rng.integers(0, s.N, (2, s.N // M)); out.append(np.where(s.F[i, m] < s.F[j, m], i, j))
        return out
    def step(s):
        pool = np.concatenate(s.subpops()); pool = np.r_[pool, s.rng.integers(0, s.N, s.N - len(pool))]
        s.X = s.offspring(s.X[s.rng.permutation(pool)]); s.F = s.evaluate(s.X)

def ut_10():
    v = VEGA(P3, budget=10, seed=1, N=60)
    for m, sub in enumerate(v.subpops()): assert v.F[sub, m].mean() < v.F[:, m].mean()    # sub-population m is biased towards low f_m
A2(10, cls_runner(VEGA), unit=ut_10)
