# Cell 3: A1. Shared toolkit (moo_utils) - moo_utils: dominance, sorting, crowding, metrics
# ---- moo_utils: dominance, sorting, crowding, metrics ----
def dom_matrix(F, CV=None):
    """D[i,j]=True if i dominates j; with CV given, Deb's three feasibility rules are applied."""
    D = (F[:, None, :] <= F[None, :, :]).all(2) & (F[:, None, :] < F[None, :, :]).any(2)
    if CV is not None:
        fe = CV <= 1e-12; a, b = fe[:, None], fe[None, :]
        D = np.where(a & b, D, np.where(a & ~b, True, np.where(~a & b, False, CV[:, None] < CV[None, :])))
    return D

def dominates(a, b): return bool(np.all(a <= b) and np.any(a < b))

def nds(F, CV=None):
    """Fast non-dominated sorting -> list of index arrays (front 0 is the best)."""
    D = dom_matrix(F, CV); cnt = D.sum(0).astype(int); left = np.ones(len(F), bool); fronts = []
    while left.any():
        cur = np.where(left & (cnt == 0))[0]
        if len(cur) == 0: cur = np.where(left)[0]
        fronts.append(cur); left[cur] = False; cnt = cnt - D[cur].sum(0)
    return fronts

def crowding(F):
    """Crowding distance of one front (boundary points get inf)."""
    n, m = F.shape; d = np.zeros(n)
    if n <= 2: return np.full(n, np.inf)
    for j in range(m):
        o = np.argsort(F[:, j]); r = F[o[-1], j] - F[o[0], j]; d[o[0]] = d[o[-1]] = np.inf
        if r > 0: d[o[1:-1]] += (F[o[2:], j] - F[o[:-2], j]) / r
    return d

def cdist(A, B): return np.sqrt(((A[:, None, :] - B[None, :, :]) ** 2).sum(2))

def nd2d(F):
    """Non-dominated subset of a 2-objective set (sort + running minimum)."""
    F = F[np.lexsort((F[:, 1], F[:, 0]))]; cm = np.minimum.accumulate(F[:, 1])
    return F[F[:, 1] < np.r_[np.inf, cm[:-1]]]

def hv2d(F, ref):
    """Exact 2-D hypervolume (minimization) by sweeping sorted points."""
    F = F[(F < ref).all(1)]
    if len(F) == 0: return 0.0
    F = F[np.argsort(F[:, 0])]; h = 0.0; best = ref[1]
    for a, b in F:
        if b < best: h += (ref[0] - a) * (best - b); best = b
    return h

def hv_mc(F, ref, n=20000, seed=0):
    """Monte-Carlo hypervolume for 3+ objectives (fixed sampling seed)."""
    F = F[(F < ref).all(1)]
    if len(F) == 0: return 0.0
    lo = F.min(0); S = np.random.default_rng(seed).uniform(lo, ref, (n, len(ref))); cov = np.zeros(n, bool)
    for i in range(0, len(F), 50): cov |= (F[i:i + 50, None, :] <= S[None]).all(2).any(0)
    return cov.mean() * np.prod(ref - lo)

def hv(F, ref): return 0.0 if len(F) == 0 else (hv2d(F, ref) if F.shape[1] == 2 else hv_mc(F, ref))
def igd(PF, F): return np.inf if len(F) == 0 else cdist(PF, F).min(1).mean()
def spacing(F):
    """Std of nearest-neighbour distances (smaller = more even)."""
    if len(F) < 3: return np.nan
    d = cdist(F, F); np.fill_diagonal(d, np.inf); return d.min(1).std()
def thin(F, n=400):
    if len(F) <= n: return F
    F = F[np.argsort(F[:, 0])]; return F[np.linspace(0, len(F) - 1, n).astype(int)]
