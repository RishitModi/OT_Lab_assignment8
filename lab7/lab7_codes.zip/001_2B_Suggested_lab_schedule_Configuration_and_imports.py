# Cell 1: 2B. Suggested lab schedule - Configuration and imports
# ---- Configuration and imports ----
import os, time, math, itertools, warnings
import numpy as np
import matplotlib
try: get_ipython(); IN_NB = True                     # inside Jupyter/Colab figures are shown inline
except NameError: IN_NB = False
if os.environ.get("QUICK") == "1" and not IN_NB: matplotlib.use("Agg")   # headless smoke-test only
import matplotlib.pyplot as plt
from scipy.optimize import minimize, linprog      # allowed ONLY inside algorithms 1-7
from IPython.display import Markdown, display
warnings.filterwarnings("ignore")

QUICK_TEST = False                                 # True -> ~1-minute dry run (tiny budget, 2 seeds)
QUICK  = QUICK_TEST or os.environ.get("QUICK") == "1"   # smoke-test switch
FULL   = True                                     # True -> 10,000 evals and 10 seeds (slow)
BUDGET = 1200 if QUICK else 5000                   # evaluations per run (2-3 objectives)
BUDGET_MANY = 2500 if QUICK else 10000             # evaluations for many-objective runs (M >= 5)
RUNS   = 2 if QUICK else 5                         # independent runs for mean ± std
if FULL: BUDGET, BUDGET_MANY, RUNS = 10000, 10000, 10
SEED0  = 2026                                      # master seed
PEN    = 10.0                                      # penalty weight on constraint violation
plt.rcParams.update({"figure.dpi": 80, "axes.grid": True})
print(f"BUDGET={BUDGET}, BUDGET_MANY={BUDGET_MANY}, RUNS={RUNS}, SEED0={SEED0}")
