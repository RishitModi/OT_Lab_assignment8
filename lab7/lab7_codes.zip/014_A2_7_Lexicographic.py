# Cell 14: A2.7 Lexicographic
def lexicographic(lin, order, tol=0.0):
    """Steps: 1) optimize highest priority  2) constrain it to its optimum (tolerance tol)  3) optimize next priority."""
    C, A, b = lin["C"], lin["A"], lin["b"]; Au, bu = A.copy(), b.copy(); bnds = list(zip(lin["lb"], lin["ub"]))
    for k in order:
        r = linprog(-C[k], A_ub=Au, b_ub=bu, bounds=bnds, method="highs"); val = -r.fun
        Au = np.vstack([Au, -C[k]]); bu = np.r_[bu, -(val * (1 - tol) - 1e-7)]
    return r.x

def ut_7():
    x = lexicographic(P11.lin, [0, 1]); assert np.allclose(x, [300, 200], atol=1e-3)     # profit tie on segment broken by units
    x1 = linprog(-P11.lin["C"][0], A_ub=P11.lin["A"], b_ub=P11.lin["b"], bounds=[(0, None)] * 2).x
    assert abs(P11.lin["C"][0] @ x1 - 2400) < 1e-6          # stage 1 alone gives 2400 but not a unique point
def run_7(P, s, b):
    sols = [lexicographic(P.lin, [0, 1]), lexicographic(P.lin, [1, 0])]
    for o, x in zip(("f1>f2", "f2>f1"), sols): print(f"  {P.name} priority {o}: x={x.round(2)}")
    return finalize(P, np.array(sols))
A2(7, run_7, unit=ut_7)
