# Cell 15: A2.8 TOPSIS and A2.9 VIKOR (ranking methods, not optimizers)
def topsis(M, w, benefit):
    """Steps: normalize columns (vector) -> weight -> ideal/anti-ideal -> distances -> closeness C = d-/(d+ + d-)."""
    V = M / np.sqrt((M ** 2).sum(0)) * w
    best = np.where(benefit, V.max(0), V.min(0)); worst = np.where(benefit, V.min(0), V.max(0))
    dp, dm = np.linalg.norm(V - best, axis=1), np.linalg.norm(V - worst, axis=1); return dm / (dp + dm + 1e-18)

def vikor(M, w, benefit, v=0.5):
    """Steps: best/worst per criterion -> S (sum), R (max) of weighted regrets -> Q = v S* + (1-v) R*; smaller Q is better."""
    fs = np.where(benefit, M.max(0), M.min(0)); fm = np.where(benefit, M.min(0), M.max(0)); r = w * (fs - M) / (fs - fm + 1e-18)
    S, R = r.sum(1), r.max(1); nz = lambda a: (a - a.min()) / (a.max() - a.min() + 1e-18)
    return v * nz(S) + (1 - v) * nz(R)

def ut_8():
    M = np.array([[1., 10.], [2., 5.], [3., 1.]]); c = topsis(M, np.array([.5, .5]), np.array([False, True]))
    assert c.argmax() == 0 and ((c >= 0) & (c <= 1)).all()   # alt 0 dominates (cheapest and best) -> closeness highest
    assert vikor(M, np.array([.5, .5]), np.array([False, True])).argmin() == 0
ut_8()
Mx, w0, bf, nm = P12["M"], P12["w"], P12["benefit"], P12["names"]
Fmin = np.where(bf, -Mx, Mx); pareto = nds(Fmin)[0]; print("P12 Pareto-optimal suppliers:", [nm[i] for i in pareto])
w1 = w0 + np.array([.1, -.1, 0, 0])                          # shift one weight by 0.1
rank = lambda sc, hi: [nm[i] for i in (np.argsort(-sc) if hi else np.argsort(sc))]
rows = [("TOPSIS w", rank(topsis(Mx, w0, bf), True)), ("TOPSIS w shifted", rank(topsis(Mx, w1, bf), True))]
for v in (.25, .5, .75): rows += [(f"VIKOR v={v}", rank(vikor(Mx, w0, bf, v), False)), (f"VIKOR v={v} shifted", rank(vikor(Mx, w1, bf, v), False))]
table([(a, " > ".join(b)) for a, b in rows], ["Method", "Ranking (best first)"])
# Apply to the reference front of P4 (risk min, return max); NSGA-II front is used again in Task D
F4 = P4.pf[::8]; M4 = np.c_[F4[:, 0], -F4[:, 1]]; c4 = topsis(M4, np.array([.5, .5]), np.array([False, True]))
print("P4 TOPSIS top-3 (risk, return):", M4[np.argsort(-c4)[:3]].round(3).tolist())
LOG += [dict(idx=8, name="TOPSIS", prob="P12/P4", budget=0, hv=np.nan, sp=np.nan, igd=np.nan, rt=0, status="works", n=5),
        dict(idx=9, name="VIKOR", prob="P12/P4", budget=0, hv=np.nan, sp=np.nan, igd=np.nan, rt=0, status="works", n=5)]
