# Cell 39: A2.32 IBEA
class IBEA(MOEA):
    """Steps: 1) pairwise eps-indicator  2) fitness F(x)=-sum exp(-I(y,x)/(c*kappa))  3) tournament on fitness  4) merge, repeatedly delete worst + update fitness. kappa=0.05."""
    kappa = 0.05
    def initialize(s): s.X = s.newpop(s.N); s.F = s.evaluate(s.X)
    def fitness(s, F):
        I = (F[:, None, :] - F[None, :, :]).max(2); E = np.exp(-I / ((np.abs(I).max() + 1e-12) * s.kappa)); np.fill_diagonal(E, 0); return -E.sum(0), E
    def select(s, F, n):
        fit, E = s.fitness(F); act = list(range(len(F)))
        while len(act) > n: w = act[int(np.argmin(fit[act]))]; act.remove(w); fit = fit + E[w]
        return np.array(act)
    def step(s):
        fit, _ = s.fitness(s.F); par = s.tourn(len(s.X), s.N, lambda i, j: fit[i] > fit[j]); off = s.offspring(s.X[par])
        XU, FU = np.vstack([s.X, off]), np.vstack([s.F, s.evaluate(off)]); sel = s.select(FU, s.N); s.X, s.F = XU[sel], FU[sel]

def ut_32():
    m = IBEA(P3, budget=10 ** 6, seed=0, N=10); fit, _ = m.fitness(np.array([[0, 0.], [1, 1.]])); assert fit[1] < fit[0]      # dominated point has lower fitness
    F = np.array([[0, 1.], [1, 0.], [.5, .5], [1, 1.]]); assert 3 not in m.select(F, 3)                                      # the dominated point is deleted first
A2(32, cls_runner(IBEA), unit=ut_32)
